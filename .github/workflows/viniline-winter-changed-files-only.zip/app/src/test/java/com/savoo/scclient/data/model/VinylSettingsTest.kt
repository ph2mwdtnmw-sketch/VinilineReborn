package com.savoo.scclient.data.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VinylSettingsTest {
    @Test
    fun everyOptionSurvivesTheRoundTrip() {
        val custom = VinylSettings(
            skin = VinylSkin.CUSTOM, customHue = 200f, customSaturation = 0.4f, customBrightness = 0.7f,
            customOpacity = 0.6f, labelMode = VinylLabelMode.COLOR, tonearm = TonearmStyle.GOLD,
            shine = 0.9f, speed = RecordSpeed.RPM_78, snowEnabled = false, snowScope = SnowScope.RECORD_ONLY,
            snowDensity = 0.8f, snowSpeed = 1.5f, snowSize = 1.3f, snowWind = -0.6f, snowTint = SnowTint.ICE,
        )
        assertEquals(custom, VinylSettings.decode(VinylSettings.encode(custom)))
    }

    @Test
    fun missingOrBrokenDataGivesDefaults() {
        assertEquals(VinylSettings(), VinylSettings.decode(null))
        assertEquals(VinylSettings(), VinylSettings.decode(""))
        assertEquals(VinylSettings(), VinylSettings.decode("garbage;;==;skin"))
    }

    @Test
    fun unknownValuesFallBackPerField() {
        val s = VinylSettings.decode("skin=PURPLE;snow=false;hue=abc;density=0.9")
        assertEquals(VinylSkin.BLACK, s.skin)
        assertFalse(s.snowEnabled)
        assertEquals(VinylSettings().customHue, s.customHue)
        assertEquals(0.9f, s.snowDensity)
    }

    @Test
    fun numbersAreClampedToTheirRange() {
        val s = VinylSettings.decode("hue=999;sat=-4;bri=0;opa=0;shine=7;density=3;fall=0;size=99;wind=-9")
        assertEquals(360f, s.customHue)
        assertEquals(0f, s.customSaturation)
        assertEquals(0.1f, s.customBrightness)
        assertEquals(0.25f, s.customOpacity)
        assertEquals(1f, s.shine)
        assertEquals(1f, s.snowDensity)
        assertEquals(0.3f, s.snowSpeed)
        assertEquals(2f, s.snowSize)
        assertEquals(-1f, s.snowWind)
    }

    @Test
    fun nanAndInfinityNeverGetThrough() {
        val s = VinylSettings(shine = Float.NaN, snowWind = Float.POSITIVE_INFINITY).normalized()
        assertTrue(s.shine.isFinite() && s.snowWind.isFinite())
    }

    @Test
    fun oldSavedDataWithFewerFieldsStillLoads() {
        val s = VinylSettings.decode("skin=ICE;snow=true")
        assertEquals(VinylSkin.ICE, s.skin)
        assertEquals(VinylSettings().snowDensity, s.snowDensity)
    }

    @Test
    fun scratchSpeedOfEachRecordSpeedIsRight() {
        assertEquals(200f, RecordSpeed.RPM_33.rpm * 6f, 0.01f) // 33 1/3 rpm = 200 degrees per second
        assertEquals(60000f / RecordSpeed.RPM_33.rpm, 1800f, 0.1f)
    }

    @Test
    fun blackSkinKeepsTheOriginalColours() {
        val p = vinylPalette(VinylSettings(skin = VinylSkin.BLACK))
        assertEquals(0xFF0B0B0D.toInt(), p.body)
        assertEquals(0xFFCFCFD6.toInt(), p.armTube) // original silver tonearm
        assertFalse(p.translucent)
    }

    @Test
    fun iceSkinIsSeeThroughAndSparkly() {
        val p = vinylPalette(VinylSettings(skin = VinylSkin.ICE))
        assertTrue(p.translucent && p.sparkle)
        assertTrue("body must be translucent but not murky", alphaOf(p.body) in 140..200)
        assertEquals(0xFF1E3550.toInt(), p.platter)
        assertEquals(0xFFEAF6FF.toInt(), p.armTube) // ice tonearm picked automatically
    }

    @Test
    fun orangeSkinIsOpaqueAndOrange() {
        val p = vinylPalette(VinylSettings(skin = VinylSkin.ORANGE))
        assertEquals(255, alphaOf(p.body))
        val r = (p.body shr 16) and 0xFF
        val b = p.body and 0xFF
        assertTrue("orange has strong red and weak blue", r > 200 && b < 80)
        assertEquals(0xFFE8C766.toInt(), p.armTube) // gold arm picked automatically
    }

    @Test
    fun customSkinFollowsTheColourAndOpacity() {
        val red = vinylPalette(VinylSettings(skin = VinylSkin.CUSTOM, customHue = 0f, customSaturation = 1f, customBrightness = 1f))
        assertEquals(0xFFFF0000.toInt(), red.body)
        val ghost = vinylPalette(VinylSettings(skin = VinylSkin.CUSTOM, customOpacity = 0.5f))
        assertTrue(ghost.translucent)
        assertTrue(alphaOf(ghost.body) in 120..135)
    }

    @Test
    fun explicitTonearmOverridesAuto() {
        val p = vinylPalette(VinylSettings(skin = VinylSkin.ICE, tonearm = TonearmStyle.BLACK))
        assertEquals(0xFF3A3A40.toInt(), p.armTube)
    }

    @Test
    fun hsvConversionIsCorrectForPrimaries() {
        assertEquals(0xFF00FF00.toInt(), hsvToArgb(120f, 1f, 1f))
        assertEquals(0xFF0000FF.toInt(), hsvToArgb(240f, 1f, 1f))
        assertEquals(0xFFFFFFFF.toInt(), hsvToArgb(77f, 0f, 1f))
        assertEquals(0xFF000000.toInt(), hsvToArgb(0f, 1f, 0f))
    }

    @Test
    fun mixAndScaleBehave() {
        assertEquals(0xFF808080.toInt(), mixArgb(0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0.5f))
        assertEquals(0xFF7F0000.toInt(), scaleRgb(0xFFFE0000.toInt(), 0.5f))
    }
}
