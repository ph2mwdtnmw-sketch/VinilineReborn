package com.savoo.scclient.ui.effects

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SnowFieldTest {
    private fun run(field: SnowField, seconds: Int, count: Int, speed: Float, wind: Float) {
        repeat(seconds * 60) { field.update(1f / 60f, count, speed, wind) }
    }

    @Test
    fun flakesStayOnScreenForever() {
        for (wind in listOf(-1f, 0f, 1f)) {
            val f = SnowField(120)
            run(f, 120, 120, 2f, wind)
            for (i in 0 until 120) {
                assertTrue("x=${f.x[i]}", f.x[i] in -0.1f..1.1f)
                assertTrue("y=${f.y[i]}", f.y[i] in -0.15f..1.1f)
            }
        }
    }

    @Test
    fun sameSeedGivesTheSameSnow() {
        val a = SnowField(50, seed = 7)
        val b = SnowField(50, seed = 7)
        run(a, 5, 50, 1f, 0.3f)
        run(b, 5, 50, 1f, 0.3f)
        for (i in 0 until 50) assertEquals(a.y[i], b.y[i], 0f)
    }

    @Test
    fun snowActuallyFalls() {
        val f = SnowField(10)
        val before = f.y.copyOf()
        f.update(0.5f, 10, 1f, 0f)
        assertTrue((0 until 10).any { f.y[it] > before[it] })
    }

    @Test
    fun windPushesTheRightWay() {
        val right = SnowField(30, seed = 3); val left = SnowField(30, seed = 3)
        val x0 = right.x.copyOf()
        run(right, 2, 30, 0.3f, 1f); run(left, 2, 30, 0.3f, -1f)
        val movedRight = (0 until 30).count { right.x[it] > x0[it] }
        val movedLeft = (0 until 30).count { left.x[it] < x0[it] }
        assertTrue("$movedRight flakes moved right", movedRight > 20)
        assertTrue("$movedLeft flakes moved left", movedLeft > 20)
    }

    @Test
    fun onlyTheRequestedFlakesMove() {
        val f = SnowField(40)
        val before = f.y.copyOf()
        f.update(0.5f, 10, 1f, 0f)
        for (i in 10 until 40) assertEquals(before[i], f.y[i], 0f)
    }

    @Test
    fun hugeTimeStepsCannotTeleportFlakes() {
        val f = SnowField(20)
        f.update(1000f, 20, 2f, 1f)
        for (i in 0 until 20) assertTrue(f.y[i] in -0.15f..1.1f)
    }

    @Test
    fun flakeSizesStayInRange() {
        val f = SnowField(500)
        run(f, 30, 500, 1f, 0f)
        for (i in 0 until 500) assertTrue(f.scale[i] in 0.25f..1f)
    }

    @Test
    fun zeroCountIsHarmless() {
        val f = SnowField(10)
        f.update(0.1f, 0, 1f, 0f)
        assertEquals(10, f.capacity)
    }
}
