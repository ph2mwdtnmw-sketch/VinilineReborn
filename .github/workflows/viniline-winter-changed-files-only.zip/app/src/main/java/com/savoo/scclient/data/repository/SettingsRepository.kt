package com.savoo.scclient.data.repository

import android.content.Context
import android.os.Build
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.savoo.scclient.data.model.UpdateChannel
import com.savoo.scclient.data.model.VinylSettings
import com.savoo.scclient.ui.theme.AppColorTheme
import com.savoo.scclient.ui.theme.OrangeSeed
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.map
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "sc_settings")

enum class DarkModeOption { SYSTEM, LIGHT, DARK }

enum class AppIconOption { NORMAL, DYNAMIC }

enum class LanguageOption(val locale: Locale?, val displayName: String) {
    ENGLISH(Locale.ENGLISH, "English"),
    RUSSIAN(Locale("ru"), "Русский"),
    CUSTOM(null, "Custom"),
}

// Only used when the user has never explicitly chosen a language: Russian devices default to Russian,
// everything else (including English) defaults to English.
fun systemDefaultLanguage(context: Context): LanguageOption =
    if (context.resources.configuration.locales[0].language == "ru") LanguageOption.RUSSIAN else LanguageOption.ENGLISH

enum class HapticsIntensity { LOW, MEDIUM, HIGH }

enum class SeekBarStyle { CLASSIC, WAVY, WAVEFORM }

enum class PlayerBackgroundStyle { ORB, BLURRED_ARTWORK, MINIMAL }

const val MinArtworkScalePercent = 60
const val MaxArtworkScalePercent = 130
const val DefaultArtworkScalePercent = 100

const val MinFontRoundness = 0
const val MaxFontRoundness = 100
const val DefaultFontRoundness = 100

enum class ArtworkShape { BLOB, CIRCLE, SQUARE, COOKIE_9, COOKIE_12, CLOVER_4, CLOVER_8, SUNNY, SOFT_BURST, FLOWER, PUFFY_DIAMOND, HEART }

enum class PlayerStyle { CLASSIC, PIXEL }

enum class AppBackgroundMode { DYNAMIC, DEFAULT, CUSTOM, PLAYER_ONLY }

enum class DividerStyle { HIDDEN, SUBTLE, BRIGHT }

enum class DrmTrackHiding { FULL, PARTIAL, OFF }

enum class ArtworkGlowSource { ARTWORK, THEME, OFF }

enum class TimedCommentsRate { OFTEN, NORMAL, RARE, EXACT }

enum class TelegramImportMode { MATCH_FIRST, DOWNLOAD_ALL }

enum class AutoExportInterval(val hours: Long) { SIX_HOURS(6), DAILY(24), WEEKLY(168) }

enum class HomeSection { JUMP_BACK_IN, FAVORITES, OFFLINE, ARTISTS, PLAYLISTS }

val CacheLimitOptionsMb = listOf(256, 512, 1024, 2048)
const val DefaultCacheLimitMb = 512

const val DefaultCrossfadeSeconds = 2
const val MinCrossfadeSeconds = 1
const val MaxCrossfadeSeconds = 12

data class HomeSectionConfig(val section: HomeSection, val visible: Boolean = true)

val DefaultHomeSections = HomeSection.entries.map { HomeSectionConfig(it) }

private fun serializeHomeSections(sections: List<HomeSectionConfig>): String =
    sections.joinToString(",") { (if (!it.visible) "-" else "") + it.section.name }

private fun parseHomeSections(raw: String?): List<HomeSectionConfig> {
    if (raw.isNullOrBlank()) return DefaultHomeSections
    val parsed = raw.split(",").mapNotNull { token ->
        val visible = !token.startsWith("-")
        val name = token.removePrefix("-")
        runCatching { HomeSection.valueOf(name) }.getOrNull()?.let { HomeSectionConfig(it, visible) }
    }
    // Cover app updates that add a new section after this list was already saved on disk.
    val missing = HomeSection.entries.filter { section -> parsed.none { it.section == section } }
        .map { HomeSectionConfig(it) }
    return parsed + missing
}

data class AppSettings(
    val colorTheme: AppColorTheme = AppColorTheme.DYNAMIC,
    val darkMode: DarkModeOption = DarkModeOption.SYSTEM,
    val dynamicFromTrack: Boolean = true,
    val liquidGlass: Boolean = false,
    val dockBackground: Boolean = true,
    val developerMode: Boolean = false,
    val language: LanguageOption = LanguageOption.ENGLISH,
    // Manual correction applied on top of the synced lyrics timestamps from the (community-sourced) lyrics
    // provider - positive shifts lines later, negative earlier. Some tracks' data is simply off by a fixed amount.
    val geniusFallbackEnabled: Boolean = true,
    val geniusAnnotationsEnabled: Boolean = true,
    val onlineFavoritesEnabled: Boolean = false,
    val updateChannel: UpdateChannel = UpdateChannel.RELEASE,
    val autoCheckUpdates: Boolean = true,
    val appIcon: AppIconOption = AppIconOption.DYNAMIC,
    val hapticsEnabled: Boolean = true,
    val hapticsIntensity: HapticsIntensity = HapticsIntensity.MEDIUM,
    val mixDiscoveryEnabled: Boolean = true,
    val onboardingCompleted: Boolean = false,
    val eulaAccepted: Boolean = false,
    val crossfadeEnabled: Boolean = false,
    val pauseForOtherApps: Boolean = true,
    val seekBarStyle: SeekBarStyle = SeekBarStyle.WAVY,
    val customSeedColor: Color = OrangeSeed.Primary,
    val homeSections: List<HomeSectionConfig> = DefaultHomeSections,
    val playerBackgroundStyle: PlayerBackgroundStyle = PlayerBackgroundStyle.ORB,
    val artworkShape: ArtworkShape = ArtworkShape.SQUARE,
    val artworkRingEnabled: Boolean = true,
    val artworkScalePercent: Int = DefaultArtworkScalePercent,
    val fontRoundnessEnabled: Boolean = true,
    val fontRoundness: Int = DefaultFontRoundness,
    val playerStyle: PlayerStyle = PlayerStyle.PIXEL,
    val backgroundMode: AppBackgroundMode = AppBackgroundMode.DYNAMIC,
    val backgroundCustomColor: Color = Color(0xFF1B1B1F),
    val playerHintShown: Boolean = false,
    val linkHintDismissed: Boolean = false,
    val recapDismissedYear: Int = 0,
    val recapEnabled: Boolean = true,
    val pixelGlowEnabled: Boolean = true,
    val beatPulseEnabled: Boolean = false,
    val animatedArtwork: Boolean = false,
    val cacheLimitMb: Int = DefaultCacheLimitMb,
    val crossfadeSeconds: Int = DefaultCrossfadeSeconds,
    val dividerStyle: DividerStyle = DividerStyle.SUBTLE,
    val drmTrackHiding: DrmTrackHiding = DrmTrackHiding.FULL,
    val artworkGlowSource: ArtworkGlowSource = ArtworkGlowSource.THEME,
    val marqueeTitles: Boolean = true,
    val timedCommentsEnabled: Boolean = true,
    val timedCommentsRate: TimedCommentsRate = TimedCommentsRate.OFTEN,
    val telegramImportMode: TelegramImportMode = TelegramImportMode.MATCH_FIRST,
    val autoExportEnabled: Boolean = false,
    val autoExportUri: String? = null,
    val autoExportInterval: AutoExportInterval = AutoExportInterval.DAILY,
    val autoExportLastRunAt: Long = 0L,
    val autoExportAccessLost: Boolean = false,
    // Vinyl skins, record customisation and the winter snow (stored as one string, see VinylSettings).
    val vinyl: VinylSettings = VinylSettings(),
)

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val COLOR_THEME = stringPreferencesKey("color_theme")
        val DARK_MODE = stringPreferencesKey("dark_mode")
        val AUTOPLAY_NEXT = booleanPreferencesKey("autoplay_next")
        val DYNAMIC_FROM_TRACK = booleanPreferencesKey("dynamic_from_track")
        val LIQUID_GLASS = booleanPreferencesKey("liquid_glass")
        val DOCK_BACKGROUND = booleanPreferencesKey("dock_background")
        val DEVELOPER_MODE = booleanPreferencesKey("developer_mode")
        val LANGUAGE = stringPreferencesKey("language")
        val GENIUS_FALLBACK_ENABLED = booleanPreferencesKey("genius_fallback_enabled")
        val GENIUS_ANNOTATIONS_ENABLED = booleanPreferencesKey("genius_annotations_enabled")
        val ONLINE_FAVORITES_ENABLED = booleanPreferencesKey("online_favorites_enabled")
        val UPDATE_CHANNEL = stringPreferencesKey("update_channel")
        val AUTO_CHECK_UPDATES = booleanPreferencesKey("auto_check_updates")
        val APP_ICON = stringPreferencesKey("app_icon")
        val HAPTICS_ENABLED = booleanPreferencesKey("haptics_enabled")
        val HAPTICS_INTENSITY = stringPreferencesKey("haptics_intensity")
        val MIX_DISCOVERY_ENABLED = booleanPreferencesKey("mix_discovery_enabled")
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val EULA_ACCEPTED = booleanPreferencesKey("eula_accepted")
        val CROSSFADE_ENABLED = booleanPreferencesKey("crossfade_enabled")
        val PAUSE_FOR_OTHER_APPS = booleanPreferencesKey("pause_for_other_apps")
        val SEEK_BAR_STYLE = stringPreferencesKey("seek_bar_style")
        val CUSTOM_SEED_COLOR = intPreferencesKey("custom_seed_color")
        val HOME_SECTIONS = stringPreferencesKey("home_sections")
        val PLAYER_BACKGROUND_STYLE = stringPreferencesKey("player_background_style")
        val ARTWORK_SHAPE = stringPreferencesKey("artwork_shape")
        val ARTWORK_RING_ENABLED = booleanPreferencesKey("artwork_ring_enabled")
        val ARTWORK_SCALE_PERCENT = intPreferencesKey("artwork_scale_percent")
        val FONT_ROUNDNESS_ENABLED = booleanPreferencesKey("font_roundness_enabled")
        val FONT_ROUNDNESS = intPreferencesKey("font_roundness")
        val PLAYER_STYLE = stringPreferencesKey("player_style")
        val BACKGROUND_MODE = stringPreferencesKey("background_mode")
        val BACKGROUND_CUSTOM_COLOR = intPreferencesKey("background_custom_color")
        val PLAYER_HINT_SHOWN = booleanPreferencesKey("player_hint_shown")
        val LINK_HINT_DISMISSED = booleanPreferencesKey("link_hint_dismissed")
        val RECAP_DISMISSED_YEAR = intPreferencesKey("recap_dismissed_year")
        val RECAP_ENABLED = booleanPreferencesKey("recap_enabled")
        val PIXEL_GLOW_ENABLED = booleanPreferencesKey("pixel_glow_enabled")
        val BEAT_PULSE_ENABLED = booleanPreferencesKey("beat_pulse_enabled")
        val ANIMATED_ARTWORK = booleanPreferencesKey("animated_artwork")
        val CACHE_LIMIT_MB = intPreferencesKey("cache_limit_mb")
        val CROSSFADE_SECONDS = intPreferencesKey("crossfade_seconds")
        val DIVIDER_STYLE = stringPreferencesKey("divider_style")
        val DRM_TRACK_HIDING = stringPreferencesKey("drm_track_hiding")
        val ARTWORK_GLOW_SOURCE = stringPreferencesKey("artwork_glow_source")
        val MARQUEE_TITLES = booleanPreferencesKey("marquee_titles")
        val TIMED_COMMENTS_ENABLED = booleanPreferencesKey("timed_comments_enabled")
        val TIMED_COMMENTS_RATE = stringPreferencesKey("timed_comments_rate")
        val TELEGRAM_IMPORT_MODE = stringPreferencesKey("telegram_import_mode")
        val AUTO_EXPORT_ENABLED = booleanPreferencesKey("auto_export_enabled")
        val AUTO_EXPORT_URI = stringPreferencesKey("auto_export_uri")
        val AUTO_EXPORT_INTERVAL = stringPreferencesKey("auto_export_interval")
        val AUTO_EXPORT_LAST_RUN_AT = longPreferencesKey("auto_export_last_run_at")
        val AUTO_EXPORT_ACCESS_LOST = booleanPreferencesKey("auto_export_access_lost")
        val VINYL = stringPreferencesKey("vinyl_settings")
    }

    private fun hasPreExistingSettings(prefs: androidx.datastore.preferences.core.Preferences): Boolean =
        prefs.asMap().keys.any { it.name != Keys.ONBOARDING_COMPLETED.name && it.name != Keys.EULA_ACCEPTED.name }

    val settings = context.dataStore.data.map { prefs ->
        AppSettings(
            colorTheme = prefs[Keys.COLOR_THEME]?.let {
                runCatching { AppColorTheme.valueOf(it) }.getOrNull()
            } ?: AppColorTheme.DYNAMIC,
            darkMode = prefs[Keys.DARK_MODE]?.let {
                runCatching { DarkModeOption.valueOf(it) }.getOrNull()
            } ?: DarkModeOption.SYSTEM,
            dynamicFromTrack = prefs[Keys.DYNAMIC_FROM_TRACK] ?: true,
            liquidGlass = prefs[Keys.LIQUID_GLASS] ?: false,
            dockBackground = prefs[Keys.DOCK_BACKGROUND] ?: true,
            developerMode = prefs[Keys.DEVELOPER_MODE] ?: false,
            language = prefs[Keys.LANGUAGE]?.let {
                runCatching { LanguageOption.valueOf(it) }.getOrNull()
            } ?: systemDefaultLanguage(context),
            geniusFallbackEnabled = prefs[Keys.GENIUS_FALLBACK_ENABLED] ?: true,
            geniusAnnotationsEnabled = prefs[Keys.GENIUS_ANNOTATIONS_ENABLED] ?: true,
            onlineFavoritesEnabled = prefs[Keys.ONLINE_FAVORITES_ENABLED] ?: false,
            updateChannel = prefs[Keys.UPDATE_CHANNEL]?.let {
                runCatching { UpdateChannel.valueOf(it) }.getOrNull()
            } ?: UpdateChannel.RELEASE,
            autoCheckUpdates = prefs[Keys.AUTO_CHECK_UPDATES] ?: true,
            appIcon = prefs[Keys.APP_ICON]?.let {
                runCatching { AppIconOption.valueOf(it) }.getOrNull()
            } ?: AppIconOption.DYNAMIC,
            hapticsEnabled = prefs[Keys.HAPTICS_ENABLED] ?: true,
            hapticsIntensity = prefs[Keys.HAPTICS_INTENSITY]?.let {
                runCatching { HapticsIntensity.valueOf(it) }.getOrNull()
            } ?: HapticsIntensity.MEDIUM,
            mixDiscoveryEnabled = prefs[Keys.MIX_DISCOVERY_ENABLED] ?: true,
            onboardingCompleted = prefs[Keys.ONBOARDING_COMPLETED] ?: hasPreExistingSettings(prefs),
            eulaAccepted = prefs[Keys.EULA_ACCEPTED] ?: hasPreExistingSettings(prefs),
            crossfadeEnabled = prefs[Keys.CROSSFADE_ENABLED] ?: false,
            pauseForOtherApps = prefs[Keys.PAUSE_FOR_OTHER_APPS] ?: true,
            seekBarStyle = prefs[Keys.SEEK_BAR_STYLE]?.let {
                runCatching { SeekBarStyle.valueOf(it) }.getOrNull()
            } ?: SeekBarStyle.WAVY,
            customSeedColor = prefs[Keys.CUSTOM_SEED_COLOR]?.let { Color(it) } ?: OrangeSeed.Primary,
            homeSections = parseHomeSections(prefs[Keys.HOME_SECTIONS]),
            // BLURRED_ARTWORK is hidden from the picker (kept working in code, just not offered as a
            // choice) - coerce anyone still holding it from before back to the default.
            artworkRingEnabled = prefs[Keys.ARTWORK_RING_ENABLED] ?: true,
            artworkScalePercent = (prefs[Keys.ARTWORK_SCALE_PERCENT] ?: DefaultArtworkScalePercent).coerceIn(MinArtworkScalePercent, MaxArtworkScalePercent),
            fontRoundnessEnabled = prefs[Keys.FONT_ROUNDNESS_ENABLED] ?: true,
            fontRoundness = (prefs[Keys.FONT_ROUNDNESS] ?: DefaultFontRoundness).coerceIn(MinFontRoundness, MaxFontRoundness),
            artworkShape = prefs[Keys.ARTWORK_SHAPE]?.let { runCatching { ArtworkShape.valueOf(it) }.getOrNull() } ?: ArtworkShape.SQUARE,
            playerBackgroundStyle = (prefs[Keys.PLAYER_BACKGROUND_STYLE]?.let {
                runCatching { PlayerBackgroundStyle.valueOf(it) }.getOrNull()
            } ?: PlayerBackgroundStyle.ORB).let {
                if (it == PlayerBackgroundStyle.BLURRED_ARTWORK) PlayerBackgroundStyle.ORB else it
            },
            playerStyle = prefs[Keys.PLAYER_STYLE]?.let {
                runCatching { PlayerStyle.valueOf(it) }.getOrNull()
            } ?: PlayerStyle.PIXEL,
            backgroundMode = prefs[Keys.BACKGROUND_MODE]?.let {
                runCatching { AppBackgroundMode.valueOf(it) }.getOrNull()
            } ?: AppBackgroundMode.DYNAMIC,
            backgroundCustomColor = prefs[Keys.BACKGROUND_CUSTOM_COLOR]?.let { Color(it) } ?: Color(0xFF1B1B1F),
            playerHintShown = prefs[Keys.PLAYER_HINT_SHOWN] ?: false,
            linkHintDismissed = prefs[Keys.LINK_HINT_DISMISSED] ?: false,
            recapDismissedYear = prefs[Keys.RECAP_DISMISSED_YEAR] ?: 0,
            recapEnabled = prefs[Keys.RECAP_ENABLED] ?: true,
            pixelGlowEnabled = prefs[Keys.PIXEL_GLOW_ENABLED] ?: true,
            beatPulseEnabled = prefs[Keys.BEAT_PULSE_ENABLED] ?: false,
            animatedArtwork = prefs[Keys.ANIMATED_ARTWORK] ?: false,
            cacheLimitMb = prefs[Keys.CACHE_LIMIT_MB] ?: DefaultCacheLimitMb,
            crossfadeSeconds = (prefs[Keys.CROSSFADE_SECONDS] ?: DefaultCrossfadeSeconds)
                .coerceIn(MinCrossfadeSeconds, MaxCrossfadeSeconds),
            dividerStyle = prefs[Keys.DIVIDER_STYLE]?.let {
                runCatching { DividerStyle.valueOf(it) }.getOrNull()
            } ?: DividerStyle.SUBTLE,
            drmTrackHiding = prefs[Keys.DRM_TRACK_HIDING]?.let {
                runCatching { DrmTrackHiding.valueOf(it) }.getOrNull()
            } ?: DrmTrackHiding.FULL,
            artworkGlowSource = prefs[Keys.ARTWORK_GLOW_SOURCE]?.let {
                runCatching { ArtworkGlowSource.valueOf(it) }.getOrNull()
            } ?: ArtworkGlowSource.THEME,
            marqueeTitles = prefs[Keys.MARQUEE_TITLES] ?: true,
            timedCommentsEnabled = prefs[Keys.TIMED_COMMENTS_ENABLED] ?: true,
            timedCommentsRate = prefs[Keys.TIMED_COMMENTS_RATE]?.let {
                runCatching { TimedCommentsRate.valueOf(it) }.getOrNull()
            } ?: TimedCommentsRate.OFTEN,
            telegramImportMode = prefs[Keys.TELEGRAM_IMPORT_MODE]?.let {
                runCatching { TelegramImportMode.valueOf(it) }.getOrNull()
            } ?: TelegramImportMode.MATCH_FIRST,
            autoExportEnabled = prefs[Keys.AUTO_EXPORT_ENABLED] ?: false,
            autoExportUri = prefs[Keys.AUTO_EXPORT_URI]?.takeIf { it.isNotBlank() },
            autoExportInterval = prefs[Keys.AUTO_EXPORT_INTERVAL]?.let {
                runCatching { AutoExportInterval.valueOf(it) }.getOrNull()
            } ?: AutoExportInterval.DAILY,
            autoExportLastRunAt = prefs[Keys.AUTO_EXPORT_LAST_RUN_AT] ?: 0L,
            autoExportAccessLost = prefs[Keys.AUTO_EXPORT_ACCESS_LOST] ?: false,
            vinyl = VinylSettings.decode(prefs[Keys.VINYL]),
        )
    }

    val autoplayNext = context.dataStore.data.map { it[Keys.AUTOPLAY_NEXT] ?: true }

    suspend fun setCrossfadeSeconds(seconds: Int) {
        context.dataStore.edit {
            it[Keys.CROSSFADE_SECONDS] = seconds.coerceIn(MinCrossfadeSeconds, MaxCrossfadeSeconds)
        }
    }

    suspend fun setCacheLimitMb(limitMb: Int) {
        context.dataStore.edit { it[Keys.CACHE_LIMIT_MB] = limitMb }
    }

    suspend fun setColorTheme(theme: AppColorTheme) {
        context.dataStore.edit { it[Keys.COLOR_THEME] = theme.name }
    }

    suspend fun setDarkMode(mode: DarkModeOption) {
        context.dataStore.edit { it[Keys.DARK_MODE] = mode.name }
    }

    /** Changes the vinyl/snow settings atomically: [transform] sees the stored value, not a stale copy. */
    suspend fun updateVinyl(transform: (VinylSettings) -> VinylSettings) {
        context.dataStore.edit { prefs ->
            val current = VinylSettings.decode(prefs[Keys.VINYL])
            prefs[Keys.VINYL] = VinylSettings.encode(transform(current))
        }
    }

    suspend fun setAutoplayNext(value: Boolean) {
        context.dataStore.edit { it[Keys.AUTOPLAY_NEXT] = value }
    }

    suspend fun setDynamicFromTrack(value: Boolean) {
        context.dataStore.edit { it[Keys.DYNAMIC_FROM_TRACK] = value }
    }

    suspend fun setLiquidGlass(value: Boolean) {
        context.dataStore.edit { it[Keys.LIQUID_GLASS] = value }
    }

    suspend fun setDockBackground(value: Boolean) {
        context.dataStore.edit { it[Keys.DOCK_BACKGROUND] = value }
    }

    suspend fun setDeveloperMode(value: Boolean) {
        context.dataStore.edit { it[Keys.DEVELOPER_MODE] = value }
    }

    suspend fun setLanguage(language: LanguageOption) {
        context.dataStore.edit { it[Keys.LANGUAGE] = language.name }
    }

    suspend fun setGeniusFallbackEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.GENIUS_FALLBACK_ENABLED] = value }
    }

    suspend fun setGeniusAnnotationsEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.GENIUS_ANNOTATIONS_ENABLED] = value }
    }

    suspend fun setOnlineFavoritesEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.ONLINE_FAVORITES_ENABLED] = value }
    }

    suspend fun setUpdateChannel(channel: UpdateChannel) {
        context.dataStore.edit { it[Keys.UPDATE_CHANNEL] = channel.name }
    }

    suspend fun setAutoCheckUpdates(value: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_CHECK_UPDATES] = value }
    }

    suspend fun setAppIcon(option: AppIconOption) {
        context.dataStore.edit { it[Keys.APP_ICON] = option.name }
    }

    suspend fun setHapticsEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.HAPTICS_ENABLED] = value }
    }

    suspend fun setHapticsIntensity(value: HapticsIntensity) {
        context.dataStore.edit { it[Keys.HAPTICS_INTENSITY] = value.name }
    }

    suspend fun setMixDiscoveryEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.MIX_DISCOVERY_ENABLED] = value }
    }

    suspend fun setOnboardingCompleted(value: Boolean) {
        context.dataStore.edit { it[Keys.ONBOARDING_COMPLETED] = value }
    }

    suspend fun setEulaAccepted(value: Boolean) {
        context.dataStore.edit { it[Keys.EULA_ACCEPTED] = value }
    }

    suspend fun setCrossfadeEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.CROSSFADE_ENABLED] = value }
    }

    suspend fun setPauseForOtherApps(value: Boolean) {
        context.dataStore.edit { it[Keys.PAUSE_FOR_OTHER_APPS] = value }
    }

    suspend fun setSeekBarStyle(style: SeekBarStyle) {
        context.dataStore.edit { it[Keys.SEEK_BAR_STYLE] = style.name }
    }

    suspend fun setCustomSeedColor(color: Color) {
        context.dataStore.edit { it[Keys.CUSTOM_SEED_COLOR] = color.toArgb() }
    }

    suspend fun setHomeSections(sections: List<HomeSectionConfig>) {
        context.dataStore.edit { it[Keys.HOME_SECTIONS] = serializeHomeSections(sections) }
    }

    suspend fun setArtworkScalePercent(value: Int) {
        context.dataStore.edit { it[Keys.ARTWORK_SCALE_PERCENT] = value.coerceIn(MinArtworkScalePercent, MaxArtworkScalePercent) }
    }

    suspend fun setFontRoundnessEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.FONT_ROUNDNESS_ENABLED] = value }
    }

    suspend fun setFontRoundness(value: Int) {
        context.dataStore.edit { it[Keys.FONT_ROUNDNESS] = value.coerceIn(MinFontRoundness, MaxFontRoundness) }
    }

    suspend fun setArtworkRingEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.ARTWORK_RING_ENABLED] = value }
    }

    suspend fun setArtworkShape(shape: ArtworkShape) {
        context.dataStore.edit { it[Keys.ARTWORK_SHAPE] = shape.name }
    }

    suspend fun setPlayerBackgroundStyle(style: PlayerBackgroundStyle) {
        context.dataStore.edit { it[Keys.PLAYER_BACKGROUND_STYLE] = style.name }
    }

    suspend fun setPlayerStyle(style: PlayerStyle) {
        context.dataStore.edit { it[Keys.PLAYER_STYLE] = style.name }
    }

    suspend fun setBackgroundMode(mode: AppBackgroundMode) {
        context.dataStore.edit { it[Keys.BACKGROUND_MODE] = mode.name }
    }

    suspend fun setBackgroundCustomColor(color: Color) {
        context.dataStore.edit { it[Keys.BACKGROUND_CUSTOM_COLOR] = color.toArgb() }
    }

    suspend fun setPlayerHintShown(value: Boolean) {
        context.dataStore.edit { it[Keys.PLAYER_HINT_SHOWN] = value }
    }

    suspend fun setLinkHintDismissed(value: Boolean) {
        context.dataStore.edit { it[Keys.LINK_HINT_DISMISSED] = value }
    }

    suspend fun setRecapDismissedYear(year: Int) {
        context.dataStore.edit { it[Keys.RECAP_DISMISSED_YEAR] = year }
    }

    suspend fun setRecapEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.RECAP_ENABLED] = value }
    }

    suspend fun setPixelGlowEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.PIXEL_GLOW_ENABLED] = value }
    }

    suspend fun setBeatPulseEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.BEAT_PULSE_ENABLED] = value }
    }

    suspend fun setAnimatedArtwork(value: Boolean) {
        context.dataStore.edit { it[Keys.ANIMATED_ARTWORK] = value }
    }

    suspend fun setDividerStyle(style: DividerStyle) {
        context.dataStore.edit { it[Keys.DIVIDER_STYLE] = style.name }
    }

    suspend fun setDrmTrackHiding(mode: DrmTrackHiding) {
        context.dataStore.edit { it[Keys.DRM_TRACK_HIDING] = mode.name }
    }

    suspend fun setArtworkGlowSource(source: ArtworkGlowSource) {
        context.dataStore.edit { it[Keys.ARTWORK_GLOW_SOURCE] = source.name }
    }

    suspend fun setMarqueeTitles(value: Boolean) {
        context.dataStore.edit { it[Keys.MARQUEE_TITLES] = value }
    }

    suspend fun setTimedCommentsEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.TIMED_COMMENTS_ENABLED] = value }
    }

    suspend fun setTimedCommentsRate(rate: TimedCommentsRate) {
        context.dataStore.edit { it[Keys.TIMED_COMMENTS_RATE] = rate.name }
    }

    suspend fun setTelegramImportMode(mode: TelegramImportMode) {
        context.dataStore.edit { it[Keys.TELEGRAM_IMPORT_MODE] = mode.name }
    }

    suspend fun setAutoExportEnabled(value: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_EXPORT_ENABLED] = value }
    }

    suspend fun setAutoExportUri(uri: String?) {
        context.dataStore.edit {
            if (uri == null) it.remove(Keys.AUTO_EXPORT_URI) else it[Keys.AUTO_EXPORT_URI] = uri
            it.remove(Keys.AUTO_EXPORT_ACCESS_LOST)
        }
    }

    suspend fun markAutoExportAccessLost() {
        context.dataStore.edit {
            it.remove(Keys.AUTO_EXPORT_URI)
            it[Keys.AUTO_EXPORT_ENABLED] = false
            it[Keys.AUTO_EXPORT_ACCESS_LOST] = true
        }
    }

    suspend fun setAutoExportInterval(interval: AutoExportInterval) {
        context.dataStore.edit { it[Keys.AUTO_EXPORT_INTERVAL] = interval.name }
    }

    suspend fun setAutoExportLastRunAt(timestamp: Long) {
        context.dataStore.edit { it[Keys.AUTO_EXPORT_LAST_RUN_AT] = timestamp }
    }
}
