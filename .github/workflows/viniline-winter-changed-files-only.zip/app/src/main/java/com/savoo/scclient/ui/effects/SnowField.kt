package com.savoo.scclient.ui.effects

import kotlin.math.PI
import kotlin.math.sin

/**
 * The physics of the falling snow, with no drawing and nothing allocated while it runs.
 *
 * Positions are fractions of the screen (0..1), so the same field works at any size. Flakes are
 * created once, evenly spread; the renderer shows the first `count` of them, which makes changing
 * the density smooth (flakes appear and disappear without the others jumping).
 */
class SnowField(val capacity: Int, seed: Int = 0x51F0A1) {
    val x = FloatArray(capacity)
    val y = FloatArray(capacity)

    /** 0.25..1: relative size, also how fast it falls and drifts (big flakes are "closer"). */
    val scale = FloatArray(capacity)
    val swayAmplitude = FloatArray(capacity)
    private val swayRate = FloatArray(capacity)
    private val phase = FloatArray(capacity)
    private val fall = FloatArray(capacity)

    private var time = 0f
    private var rng = if (seed == 0) 1 else seed

    init {
        for (i in 0 until capacity) {
            x[i] = random()
            y[i] = random()
            reroll(i)
        }
    }

    /** Horizontal position including the gentle side-to-side sway, ready to draw. */
    fun drawX(i: Int): Float = x[i] + sin(time * swayRate[i] + phase[i]) * swayAmplitude[i]

    fun update(dtSeconds: Float, count: Int, speed: Float, wind: Float) {
        val dt = dtSeconds.coerceIn(0f, 0.1f)
        time += dt
        val n = count.coerceIn(0, capacity)
        for (i in 0 until n) {
            y[i] += fall[i] * speed * dt
            x[i] += wind * 0.05f * (0.4f + scale[i]) * dt
            if (y[i] > 1.05f) {
                y[i] -= 1.1f
                x[i] = random()
                reroll(i)
            }
            if (x[i] > 1.05f) x[i] -= 1.1f else if (x[i] < -0.05f) x[i] += 1.1f
        }
    }

    private fun reroll(i: Int) {
        val s = 0.25f + 0.75f * random() * random().let { 0.35f + 0.65f * it }
        scale[i] = s.coerceIn(0.25f, 1f)
        fall[i] = 0.05f + 0.13f * scale[i] + 0.02f * random()
        swayAmplitude[i] = 0.004f + 0.012f * random()
        swayRate[i] = 0.6f + 1.4f * random()
        phase[i] = (2f * PI.toFloat()) * random()
    }

    private fun random(): Float {
        var v = rng
        v = v xor (v shl 13)
        v = v xor (v ushr 17)
        v = v xor (v shl 5)
        rng = v
        return (v ushr 8) / 16777216f
    }
}
