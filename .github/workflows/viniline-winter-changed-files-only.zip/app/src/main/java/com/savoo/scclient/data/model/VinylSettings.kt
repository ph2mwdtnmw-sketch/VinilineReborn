package com.savoo.scclient.data.model

/*
 * Everything the user can customise about the vinyl record and the winter snow. Pure Kotlin (no
 * Android or Compose types) so it can be unit-tested; the whole thing is stored as ONE string in
 * the settings (see encode/decode), so adding an option never needs a new storage key.
 */

enum class VinylSkin { BLACK, ORANGE, ICE, CUSTOM }

/** What sits in the middle of the record. */
enum class VinylLabelMode { ARTWORK, COLOR }

enum class TonearmStyle { AUTO, SILVER, GOLD, BLACK, ICE, ORANGE }

/** How fast the platter turns. [rpm] is also what the scratch gesture is measured against. */
enum class RecordSpeed(val rpm: Float) {
    RPM_33(100f / 3f),
    RPM_45(45f),
    RPM_78(78f),
}

enum class SnowScope { EVERYWHERE, RECORD_ONLY }

enum class SnowTint { WHITE, ICE, GOLD }

data class VinylSettings(
    val skin: VinylSkin = VinylSkin.BLACK,
    /** Colour of the CUSTOM skin: hue 0..360, saturation and brightness 0..1, opacity 0.25..1. */
    val customHue: Float = 28f,
    val customSaturation: Float = 0.9f,
    val customBrightness: Float = 0.95f,
    val customOpacity: Float = 1f,
    val labelMode: VinylLabelMode = VinylLabelMode.ARTWORK,
    val tonearm: TonearmStyle = TonearmStyle.AUTO,
    /** Strength of the light reflection on the vinyl, 0..1. */
    val shine: Float = 0.6f,
    val speed: RecordSpeed = RecordSpeed.RPM_33,
    val snowEnabled: Boolean = true,
    val snowScope: SnowScope = SnowScope.EVERYWHERE,
    /** 0..1: how many flakes. */
    val snowDensity: Float = 0.5f,
    /** 0.3..2: how fast they fall. */
    val snowSpeed: Float = 1f,
    /** 0.5..2: how big they are. */
    val snowSize: Float = 1f,
    /** -1..1: sideways drift, negative to the left. */
    val snowWind: Float = 0.2f,
    val snowTint: SnowTint = SnowTint.WHITE,
) {
    /** The same settings with every number forced into its valid range. */
    fun normalized(): VinylSettings = copy(
        customHue = customHue.finiteOr(28f).coerceIn(0f, 360f),
        customSaturation = customSaturation.finiteOr(0.9f).coerceIn(0f, 1f),
        customBrightness = customBrightness.finiteOr(0.95f).coerceIn(0.1f, 1f),
        customOpacity = customOpacity.finiteOr(1f).coerceIn(0.25f, 1f),
        shine = shine.finiteOr(0.6f).coerceIn(0f, 1f),
        snowDensity = snowDensity.finiteOr(0.5f).coerceIn(0f, 1f),
        snowSpeed = snowSpeed.finiteOr(1f).coerceIn(0.3f, 2f),
        snowSize = snowSize.finiteOr(1f).coerceIn(0.5f, 2f),
        snowWind = snowWind.finiteOr(0.2f).coerceIn(-1f, 1f),
    )

    companion object {
        fun encode(s: VinylSettings): String = with(s.normalized()) {
            listOf(
                "skin=$skin", "hue=$customHue", "sat=$customSaturation", "bri=$customBrightness",
                "opa=$customOpacity", "label=$labelMode", "arm=$tonearm", "shine=$shine",
                "speed=$speed", "snow=$snowEnabled", "scope=$snowScope", "density=$snowDensity",
                "fall=$snowSpeed", "size=$snowSize", "wind=$snowWind", "tint=$snowTint",
            ).joinToString(";")
        }

        /** Reads what [encode] wrote. Unknown, missing or broken parts fall back to the defaults. */
        fun decode(raw: String?): VinylSettings {
            if (raw.isNullOrBlank()) return VinylSettings()
            val map = raw.split(";").mapNotNull {
                val i = it.indexOf('=')
                if (i <= 0) null else it.substring(0, i).trim() to it.substring(i + 1).trim()
            }.toMap()
            val d = VinylSettings()
            return VinylSettings(
                skin = enumOr(map["skin"], d.skin),
                customHue = map["hue"]?.toFloatOrNull() ?: d.customHue,
                customSaturation = map["sat"]?.toFloatOrNull() ?: d.customSaturation,
                customBrightness = map["bri"]?.toFloatOrNull() ?: d.customBrightness,
                customOpacity = map["opa"]?.toFloatOrNull() ?: d.customOpacity,
                labelMode = enumOr(map["label"], d.labelMode),
                tonearm = enumOr(map["arm"], d.tonearm),
                shine = map["shine"]?.toFloatOrNull() ?: d.shine,
                speed = enumOr(map["speed"], d.speed),
                snowEnabled = map["snow"]?.toBooleanStrictOrNull() ?: d.snowEnabled,
                snowScope = enumOr(map["scope"], d.snowScope),
                snowDensity = map["density"]?.toFloatOrNull() ?: d.snowDensity,
                snowSpeed = map["fall"]?.toFloatOrNull() ?: d.snowSpeed,
                snowSize = map["size"]?.toFloatOrNull() ?: d.snowSize,
                snowWind = map["wind"]?.toFloatOrNull() ?: d.snowWind,
                snowTint = enumOr(map["tint"], d.snowTint),
            ).normalized()
        }

        private inline fun <reified E : Enum<E>> enumOr(name: String?, default: E): E =
            enumValues<E>().firstOrNull { it.name == name } ?: default
    }
}

private fun Float.finiteOr(fallback: Float): Float = if (isNaN() || isInfinite()) fallback else this
