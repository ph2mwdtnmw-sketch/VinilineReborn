package com.savoo.scclient.data.model

import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * The colours of one record skin, as plain ARGB ints (so this stays free of Compose and can be
 * tested). The UI turns them into Colors.
 */
data class VinylPalette(
    val body: Int,
    val grooveA: Int,
    val grooveB: Int,
    val gap: Int,
    val edge: Int,
    val platter: Int,
    val platterRim: Int,
    /** Dots printed on the platter; only visible through a see-through record. */
    val strobe: Int,
    val labelBg: Int,
    val labelRing: Int,
    val spindle: Int,
    val armTube: Int,
    val armHead: Int,
    val armWeight: Int,
    val armBase: Int,
    val armBaseRim: Int,
    val armPivot: Int,
    /** The record lets the platter show through. */
    val translucent: Boolean,
    /** Draw small glints of light on the record (ice). */
    val sparkle: Boolean,
)

fun vinylPalette(settings: VinylSettings): VinylPalette {
    val s = settings.normalized()
    val base = when (s.skin) {
        VinylSkin.BLACK -> blackPalette()
        VinylSkin.ORANGE -> orangePalette()
        VinylSkin.ICE -> icePalette()
        VinylSkin.CUSTOM -> customPalette(s)
    }
    val arm = armColors(
        if (s.tonearm == TonearmStyle.AUTO) autoTonearm(s.skin) else s.tonearm,
    )
    return base.copy(
        armTube = arm.tube,
        armHead = arm.head,
        armWeight = arm.weight,
        armBase = arm.base,
        armBaseRim = arm.rim,
        armPivot = arm.pivot,
    )
}

private fun autoTonearm(skin: VinylSkin) = when (skin) {
    VinylSkin.BLACK, VinylSkin.CUSTOM -> TonearmStyle.SILVER
    VinylSkin.ORANGE -> TonearmStyle.GOLD
    VinylSkin.ICE -> TonearmStyle.ICE
}

private class ArmColors(val tube: Int, val head: Int, val weight: Int, val base: Int, val rim: Int, val pivot: Int)

private fun armColors(style: TonearmStyle): ArmColors = when (style) {
    TonearmStyle.GOLD -> ArmColors(0xFFE8C766.toInt(), 0xFFB8943A.toInt(), 0xFF8A6D24.toInt(), 0xFF2B2415.toInt(), 0xFFD4AF37.toInt(), 0xFFFFF1C2.toInt())
    TonearmStyle.BLACK -> ArmColors(0xFF3A3A40.toInt(), 0xFF222226.toInt(), 0xFF18181B.toInt(), 0xFF0E0E10.toInt(), 0xFF4A4A52.toInt(), 0xFF6E6E78.toInt())
    TonearmStyle.ICE -> ArmColors(0xFFEAF6FF.toInt(), 0xFFB5DCF5.toInt(), 0xFF8FC7F0.toInt(), 0xFF1E3550.toInt(), 0xFF8FC7F0.toInt(), 0xFFFFFFFF.toInt())
    TonearmStyle.ORANGE -> ArmColors(0xFFFFB066.toInt(), 0xFFF28A1E.toInt(), 0xFFB85F0A.toInt(), 0xFF2B1B10.toInt(), 0xFFFFB066.toInt(), 0xFFFFE2C2.toInt())
    // SILVER, and AUTO should never reach here (resolved by the caller).
    else -> ArmColors(0xFFCFCFD6.toInt(), 0xFF9B9BA5.toInt(), 0xFF6E6E78.toInt(), 0xFF1B1B1F.toInt(), 0xFF4A4A52.toInt(), 0xFFE6E6EB.toInt())
}

private fun blackPalette() = VinylPalette(
    body = 0xFF0B0B0D.toInt(), grooveA = 0xFF1D1D21.toInt(), grooveB = 0xFF121215.toInt(),
    gap = 0xFF2A2A2F.toInt(), edge = 0x26FFFFFF,
    platter = 0xFF26262A.toInt(), platterRim = 0xFF3C3C42.toInt(), strobe = 0x00000000,
    labelBg = 0xFF1A1A1D.toInt(), labelRing = 0xFF3A3A40.toInt(), spindle = 0xFF1A1A1D.toInt(),
    armTube = 0, armHead = 0, armWeight = 0, armBase = 0, armBaseRim = 0, armPivot = 0,
    translucent = false, sparkle = false,
)

private fun orangePalette(): VinylPalette {
    val base = 0xFFF28A1E.toInt()
    return VinylPalette(
        body = base, grooveA = scaleRgb(base, 0.88f), grooveB = scaleRgb(base, 0.78f),
        gap = mixArgb(base, 0xFFFFFFFF.toInt(), 0.35f), edge = 0x40FFFFFF,
        platter = 0xFF26262A.toInt(), platterRim = 0xFF3C3C42.toInt(), strobe = 0x00000000,
        labelBg = 0xFF2B1B10.toInt(), labelRing = 0xFFFFB066.toInt(), spindle = 0xFF1A1A1D.toInt(),
        armTube = 0, armHead = 0, armWeight = 0, armBase = 0, armBaseRim = 0, armPivot = 0,
        translucent = false, sparkle = false,
    )
}

private fun icePalette() = VinylPalette(
    body = 0xB8E3F3FF.toInt(), grooveA = 0x73FFFFFF, grooveB = 0x40AEDBFF,
    gap = 0xB3FFFFFF.toInt(), edge = 0xE6FFFFFF.toInt(),
    platter = 0xFF1E3550.toInt(), platterRim = 0xFF7FB6E0.toInt(), strobe = 0x80D6EEFF.toInt(),
    labelBg = 0xFFEAF6FF.toInt(), labelRing = 0xFF8FC7F0.toInt(), spindle = 0xFF1E3550.toInt(),
    armTube = 0, armHead = 0, armWeight = 0, armBase = 0, armBaseRim = 0, armPivot = 0,
    translucent = true, sparkle = true,
)

private fun customPalette(s: VinylSettings): VinylPalette {
    val opaque = hsvToArgb(s.customHue, s.customSaturation, s.customBrightness, 1f)
    val alpha = (s.customOpacity * 255f).roundToInt().coerceIn(0, 255)
    val base = withAlpha(opaque, alpha)
    val translucent = s.customOpacity < 0.95f
    return VinylPalette(
        body = base,
        grooveA = withAlpha(scaleRgb(opaque, 0.88f), alpha),
        grooveB = withAlpha(scaleRgb(opaque, 0.78f), alpha),
        gap = withAlpha(mixArgb(opaque, 0xFFFFFFFF.toInt(), 0.30f), alpha),
        edge = 0x40FFFFFF,
        platter = 0xFF26262A.toInt(), platterRim = 0xFF3C3C42.toInt(),
        strobe = if (translucent) 0x66FFFFFF else 0x00000000,
        labelBg = scaleRgb(opaque, 0.40f), labelRing = mixArgb(opaque, 0xFFFFFFFF.toInt(), 0.35f),
        spindle = 0xFF1A1A1D.toInt(),
        armTube = 0, armHead = 0, armWeight = 0, armBase = 0, armBaseRim = 0, armPivot = 0,
        translucent = translucent, sparkle = false,
    )
}

// --- tiny colour maths on ARGB ints --------------------------------------------------------

fun alphaOf(argb: Int): Int = (argb ushr 24) and 0xFF

fun withAlpha(argb: Int, alpha: Int): Int = (alpha.coerceIn(0, 255) shl 24) or (argb and 0x00FFFFFF)

/** Multiplies the RGB channels (not alpha) by [factor]. */
fun scaleRgb(argb: Int, factor: Float): Int {
    val r = (((argb shr 16) and 0xFF) * factor).roundToInt().coerceIn(0, 255)
    val g = (((argb shr 8) and 0xFF) * factor).roundToInt().coerceIn(0, 255)
    val b = ((argb and 0xFF) * factor).roundToInt().coerceIn(0, 255)
    return (alphaOf(argb) shl 24) or (r shl 16) or (g shl 8) or b
}

/** Linear mix of two colours, [t] = 0 gives [a], 1 gives [b]. Alpha is mixed too. */
fun mixArgb(a: Int, b: Int, t: Float): Int {
    fun ch(shift: Int): Int {
        val x = (a shr shift) and 0xFF
        val y = (b shr shift) and 0xFF
        return (x + (y - x) * t).roundToInt().coerceIn(0, 255)
    }
    return (ch(24) shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
}

fun hsvToArgb(hue: Float, saturation: Float, value: Float, alpha: Float = 1f): Int {
    val h = ((hue % 360f) + 360f) % 360f
    val c = value * saturation
    val x = c * (1f - abs((h / 60f) % 2f - 1f))
    val m = value - c
    val (r, g, b) = when {
        h < 60f -> Triple(c, x, 0f)
        h < 120f -> Triple(x, c, 0f)
        h < 180f -> Triple(0f, c, x)
        h < 240f -> Triple(0f, x, c)
        h < 300f -> Triple(x, 0f, c)
        else -> Triple(c, 0f, x)
    }
    fun to255(v: Float) = ((v + m) * 255f).roundToInt().coerceIn(0, 255)
    return ((alpha * 255f).roundToInt().coerceIn(0, 255) shl 24) or (to255(r) shl 16) or (to255(g) shl 8) or to255(b)
}
