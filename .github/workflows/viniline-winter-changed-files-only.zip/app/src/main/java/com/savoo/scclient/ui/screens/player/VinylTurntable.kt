package com.savoo.scclient.ui.screens.player

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.ContextWrapper
import android.view.Window
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import com.savoo.scclient.data.model.VinylLabelMode
import com.savoo.scclient.data.model.VinylPalette
import com.savoo.scclient.data.model.SnowScope
import com.savoo.scclient.data.model.vinylPalette
import com.savoo.scclient.ui.components.TrackArtwork
import com.savoo.scclient.ui.effects.LocalVinylSettings
import com.savoo.scclient.ui.effects.SnowOverlay
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.exp
import kotlin.math.roundToInt

/**
 * A vinyl record on a turntable that replaces the plain cover art in the full-screen player.
 *
 * - The record spins at 33 1/3 rpm multiplied by the current playback rate, so "slowed" and
 *   "sped up" modes visibly change the turntable speed. Starting and stopping has inertia.
 * - Touching the record stops it (like a hand on the platter). Dragging it in a circle winds the
 *   track forward (clockwise) or backward (counter-clockwise). Letting go resumes playback.
 * - The tonearm lowers onto the record while playing and travels from the outer groove to the
 *   inner groove as the track progresses.
 *
 * Performance notes for old phones: the record is drawn once and only its layer rotation changes
 * every frame (no recomposition, no redraw). The frame loop sleeps completely while the record is
 * stopped. There are no blurs, shadows or large bitmaps.
 */
@Composable
fun VinylTurntable(
    artworkUrl: String?,
    artworkSeed: Any?,
    isPlaying: Boolean,
    /** Effective playback rate: user speed multiplied by the sound mode rate. 1f = 33 1/3 rpm. */
    rate: Float,
    positionMs: Long,
    durationMs: Long,
    onSeek: (Long) -> Unit,
    /** Finger landed on a record that is playing: switch the audio to scratch mode (arg: current rate). */
    onScratchStart: (Float) -> Unit,
    /** Finger speed as a multiple of normal 33 1/3 rpm forward speed (negative = backwards). */
    onScratchSpeed: (Float) -> Unit,
    /** Finger let go. Args: the position the record was wound to, and whether the player should move there. */
    onScratchEnd: (Long, Boolean) -> Unit,
    /** Called shortly after playback starts, so the scratch audio output can be set up in advance. */
    onPrepareScratch: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    // Skin, label, tonearm, speed and snow all come from the customisation settings.
    val vinyl = LocalVinylSettings.current
    val palette = remember(vinyl.skin, vinyl.customHue, vinyl.customSaturation, vinyl.customBrightness, vinyl.customOpacity, vinyl.tonearm) {
        vinylPalette(vinyl)
    }
    val colors = remember(palette) { VinylColors(palette) }
    val rpm = vinyl.speed.rpm
    val baseDegreesPerSecond = rpm * 6f // 33 1/3 rpm = 200 degrees per second
    val latestRpm by rememberUpdatedState(rpm)

    val angle = remember { mutableFloatStateOf(0f) }
    val targetSpeed = remember { mutableFloatStateOf(0f) }
    var held by remember { mutableStateOf(false) }
    var scrubPositionMs by remember { mutableLongStateOf(0L) }

    val latestIsPlaying by rememberUpdatedState(isPlaying)
    val latestPositionMs by rememberUpdatedState(positionMs)
    val latestDurationMs by rememberUpdatedState(durationMs)
    val latestRate by rememberUpdatedState(rate)
    val latestSeek by rememberUpdatedState(onSeek)
    val latestScratchStart by rememberUpdatedState(onScratchStart)
    val latestScratchSpeed by rememberUpdatedState(onScratchSpeed)
    val latestScratchEnd by rememberUpdatedState(onScratchEnd)

    val latestPrepare by rememberUpdatedState(onPrepareScratch)
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            delay(800) // let the first audio reach the processor so there is a history to prepare for
            latestPrepare()
        }
    }

    // Ask the display for its fastest mode (up to 144 Hz) only while the record is actually moving.
    HighRefreshRateWhile(enabled = isPlaying || held)
    val context = LocalContext.current
    val lowRam = remember {
        (context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager)?.isLowRamDevice == true
    }

    SideEffect {
        targetSpeed.floatValue = if (isPlaying && !held) baseDegreesPerSecond * rate.coerceAtLeast(0f) else 0f
    }

    // The spin loop. It sleeps (no frames requested at all) while the record is fully stopped.
    LaunchedEffect(Unit) {
        var lastNanos = withFrameNanosCompat()
        var velocity = 0f
        while (true) {
            val target = targetSpeed.floatValue
            if (target == 0f && velocity < IDLE_DEGREES_PER_SECOND) {
                velocity = 0f
                snapshotFlow { targetSpeed.floatValue }.first { it > 0f }
                lastNanos = withFrameNanosCompat()
                continue
            }
            // Low-RAM phones spin the record at half the frame rate to save battery and GPU time.
            if (lowRam) withFrameNanosCompat()
            val now = withFrameNanosCompat()
            val dt = ((now - lastNanos) / 1_000_000_000f).coerceIn(0f, 0.1f)
            lastNanos = now
            val tau = when {
                target > velocity -> SPIN_UP_TAU
                held -> HAND_BRAKE_TAU
                else -> COAST_TAU
            }
            velocity += (target - velocity) * (1f - exp(-dt / tau))
            angle.floatValue = (angle.floatValue + velocity * dt) % 360f
        }
    }

    val rawProgress = if (durationMs > 0L) {
        ((if (held) scrubPositionMs else positionMs).toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    // Snap to 0.5% steps: the tonearm moves a fraction of a pixel per position tick, so this saves
    // a recomposition every few hundred milliseconds for nothing visible.
    val progress = (rawProgress * ARM_PROGRESS_STEPS).roundToInt() / ARM_PROGRESS_STEPS
    val armDown = (isPlaying || held) && durationMs > 0L
    val armAngle = animateFloatAsState(
        targetValue = if (armDown) ARM_START_DEG + (ARM_END_DEG - ARM_START_DEG) * progress else ARM_REST_DEG,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessLow),
        label = "tonearm",
    )

    BoxWithConstraints(modifier = modifier) {
        val s = maxWidth
        val recordSize = s * (RECORD_RADIUS * 2f)
        val labelSize = recordSize * LABEL_FRACTION

        // 1) Static platter + soft shadow, behind everything.
        Canvas(modifier = Modifier.fillMaxSize()) {
            val sc = size.minDimension
            val c = Offset(sc * CENTER_X, sc * CENTER_Y)
            drawCircle(Color(0x33000000), radius = sc * (PLATTER_RADIUS + 0.012f), center = c + Offset(0f, sc * 0.014f))
            drawCircle(colors.platter, radius = sc * PLATTER_RADIUS, center = c)
            drawCircle(
                colors.platterRim,
                radius = sc * PLATTER_RADIUS,
                center = c,
                style = Stroke(width = sc * 0.004f),
            )
            // Strobe dots on the platter: only noticeable through a see-through record.
            if (colors.strobe.alpha > 0f) {
                for (ring in STROBE_RINGS) {
                    for (k in 0 until STROBE_DOTS) {
                        val a = k * (2.0 * Math.PI / STROBE_DOTS)
                        drawCircle(
                            colors.strobe,
                            radius = sc * 0.0035f,
                            center = Offset(c.x + (cos(a) * sc * ring).toFloat(), c.y + (sin(a) * sc * ring).toFloat()),
                        )
                    }
                }
            }
        }

        // 2) The record itself. Gestures live on the NON-rotating wrapper, so finger coordinates
        //    stay in screen space while the layer inside rotates.
        Box(
            modifier = Modifier
                .offset(x = s * (CENTER_X - RECORD_RADIUS), y = s * (CENTER_Y - RECORD_RADIUS))
                .size(recordSize)
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        val cx = size.width / 2f
                        val cy = size.height / 2f
                        val dx0 = down.position.x - cx
                        val dy0 = down.position.y - cy
                        val radius = size.width / 2f
                        if (dx0 * dx0 + dy0 * dy0 > radius * radius) return@awaitEachGesture
                        down.consume()

                        // A playing record is "scratched": the audio engine plays the last seconds of
                        // the track at the finger's speed, and the real player is only moved on release.
                        // A stopped record just seeks silently while it is dragged.
                        val scratching = latestIsPlaying
                        val startDuration = latestDurationMs
                        held = true
                        scrubPositionMs = latestPositionMs
                        if (scratching) latestScratchStart(latestRate)
                        var lastAngle = atan2(dy0, dx0)
                        var lastTime = down.uptimeMillis
                        var lastSeekAt = 0L
                        var moved = false
                        // Finger speed is the slope of the angle over the last ~25 ms. A single
                        // event-to-event difference is far too noisy, especially at 120/144 Hz
                        // where events are only 7-8 ms apart and timestamps have 1 ms resolution.
                        val sampleTimes = LongArray(VELOCITY_SAMPLES)
                        val sampleAngles = FloatArray(VELOCITY_SAMPLES)
                        var sampleCount = 1
                        var totalAngle = 0f
                        sampleTimes[0] = lastTime
                        try {
                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                                // Stamp the time first, so the lift itself counts towards how long the
                                // record was held, even if the finger never moved.
                                val now = change.uptimeMillis
                                lastTime = now
                                if (!change.pressed) {
                                    change.consume()
                                    break
                                }
                                val a = atan2(change.position.y - cy, change.position.x - cx)
                                var d = (a - lastAngle) * RAD_TO_DEG
                                if (d > 180f) d -= 360f else if (d < -180f) d += 360f
                                lastAngle = a
                                if (d != 0f) {
                                    angle.floatValue = (angle.floatValue + d) % 360f
                                    val maxMs = latestDurationMs.coerceAtLeast(0L)
                                    scrubPositionMs = (scrubPositionMs + (d / 360f * (60_000f / latestRpm)).toLong())
                                        .coerceIn(0L, maxMs)
                                    totalAngle += d
                                    // Ignore the few degrees of jitter of a resting finger.
                                    if (abs(totalAngle) > MOVE_SLOP_DEGREES) moved = true
                                    sampleTimes[sampleCount % VELOCITY_SAMPLES] = now
                                    sampleAngles[sampleCount % VELOCITY_SAMPLES] = totalAngle
                                    sampleCount++
                                    if (scratching) {
                                        var ref = sampleCount - 1
                                        var k = sampleCount - 2
                                        while (k >= 0 && k > sampleCount - 1 - VELOCITY_SAMPLES) {
                                            ref = k
                                            if (now - sampleTimes[k % VELOCITY_SAMPLES] >= VELOCITY_WINDOW_MS) break
                                            k--
                                        }
                                        val span = now - sampleTimes[ref % VELOCITY_SAMPLES]
                                        if (span > 0L) {
                                            val degreesPerSecond =
                                                (totalAngle - sampleAngles[ref % VELOCITY_SAMPLES]) / span * 1000f
                                            latestScratchSpeed(degreesPerSecond / (latestRpm * 6f))
                                        }
                                    } else if (now - lastSeekAt >= SEEK_THROTTLE_MS) {
                                        lastSeekAt = now
                                        latestSeek(scrubPositionMs)
                                    }
                                }
                                change.consume()
                            }
                        } finally {
                            // A quick tap that never turned the record must not rewind or interrupt
                            // the music. Holding it for a moment does count (the record was stopped).
                            // If the track changed under the finger (it ended while held), do not
                            // drag the new track to a position that belonged to the old one.
                            val heldMs = lastTime - down.uptimeMillis
                            val sameTrack = latestDurationMs == startDuration
                            val shouldSeek = sameTrack && (moved || heldMs >= TAP_MAX_MS)
                            if (scratching) {
                                latestScratchEnd(scrubPositionMs, shouldSeek)
                            } else if (shouldSeek) {
                                latestSeek(scrubPositionMs)
                            }
                            held = false
                        }
                    }
                },
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { rotationZ = angle.floatValue }
                    .drawBehind { drawRecordGrooves(colors) },
                contentAlignment = Alignment.Center,
            ) {
                if (vinyl.labelMode == VinylLabelMode.COLOR) {
                    // A plain printed label instead of the cover art.
                    Box(
                        modifier = Modifier
                            .size(labelSize)
                            .background(colors.labelBg, CircleShape)
                            .drawBehind {
                                val r = size.minDimension / 2f
                                drawCircle(colors.labelRing, radius = r * 0.92f, style = Stroke(width = r * 0.05f))
                                drawCircle(colors.labelRing, radius = r * 0.55f, style = Stroke(width = r * 0.03f))
                            },
                    )
                } else {
                    TrackArtwork(
                        artworkUrl = artworkUrl,
                        contentDescription = null,
                        seed = artworkSeed,
                        shape = CircleShape,
                        modifier = Modifier.size(labelSize),
                    )
                }
                Box(
                    modifier = Modifier
                        .size(recordSize * 0.035f)
                        .background(colors.spindle, CircleShape),
                )
            }
            // Fixed light reflection on top of the spinning vinyl: this is what makes the
            // rotation readable, since the grooves themselves are uniform circles.
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawBehind {
                        // 0.6 (the default) is the original strength; see-through skins get a little more.
                        val strength = (vinyl.shine * 0.30f * (if (colors.translucent) 1.5f else 1f)).coerceIn(0f, 0.6f)
                        if (strength > 0f) {
                            val shineColor = Color(1f, 1f, 1f, strength)
                            val brush = Brush.sweepGradient(
                                0.00f to Color.Transparent,
                                0.06f to shineColor,
                                0.14f to Color.Transparent,
                                0.50f to Color.Transparent,
                                0.56f to shineColor,
                                0.64f to Color.Transparent,
                                1.00f to Color.Transparent,
                                center = center,
                            )
                            drawCircle(brush = brush, radius = size.minDimension / 2f, center = center)
                        }
                        if (colors.sparkle && vinyl.shine > 0f) drawGlints(vinyl.shine)
                    },
            )
        }

        // 3) Tonearm, on top. Reads the animated angle only in the draw phase.
        Canvas(modifier = Modifier.fillMaxSize()) {
            val sc = size.minDimension
            val pivot = Offset(sc * PIVOT_X, sc * PIVOT_Y)
            val armLength = sc * ARM_LENGTH
            val headLength = sc * 0.06f

            drawCircle(colors.armBase, radius = sc * 0.07f, center = pivot)
            drawCircle(colors.armBaseRim, radius = sc * 0.07f, center = pivot, style = Stroke(width = sc * 0.006f))
            rotate(degrees = armAngle.value, pivot = pivot) {
                // counterweight behind the pivot
                drawLine(
                    color = colors.armWeight,
                    start = pivot,
                    end = pivot + Offset(0f, -sc * 0.07f),
                    strokeWidth = sc * 0.045f,
                    cap = StrokeCap.Round,
                )
                // arm tube
                drawLine(
                    color = colors.armTube,
                    start = pivot,
                    end = pivot + Offset(0f, armLength - headLength),
                    strokeWidth = sc * 0.014f,
                    cap = StrokeCap.Round,
                )
                // headshell with the needle at its tip
                drawLine(
                    color = colors.armHead,
                    start = pivot + Offset(0f, armLength - headLength),
                    end = pivot + Offset(0f, armLength),
                    strokeWidth = sc * 0.032f,
                    cap = StrokeCap.Round,
                )
            }
            drawCircle(colors.armPivot, radius = sc * 0.02f, center = pivot)
        }

        // Snow that falls only on the record (the other option is snow over the whole app).
        if (vinyl.snowScope == SnowScope.RECORD_ONLY) {
            SnowOverlay(settings = vinyl, modifier = Modifier.fillMaxSize())
        }
    }
}

private fun DrawScope.drawRecordGrooves(colors: VinylColors) {
    val c = center
    val r = size.minDimension / 2f
    drawCircle(colors.body, radius = r, center = c)
    var radius = r * 0.97f
    var i = 0
    while (radius > r * 0.40f) {
        val color = when {
            i % 9 == 8 -> colors.gap // a "gap" between tracks
            i % 3 == 0 -> colors.grooveA
            else -> colors.grooveB
        }
        drawCircle(color = color, radius = radius, center = c, style = Stroke(width = 1.2f))
        radius -= r * 0.018f
        i++
    }
    drawCircle(colors.edge, radius = r - 1f, center = c, style = Stroke(width = 2f))
}

/** A few small four-pointed glints of light on the see-through (ice) record. */
private fun DrawScope.drawGlints(strength: Float) {
    val c = center
    val r = size.minDimension / 2f
    for (g in GLINTS) {
        val a = Math.toRadians(g[0].toDouble())
        val p = Offset(c.x + (cos(a) * g[1] * r).toFloat(), c.y + (sin(a) * g[1] * r).toFloat())
        val len = g[2] * r
        val color = Color(1f, 1f, 1f, (0.55f * strength + 0.25f).coerceIn(0f, 0.85f))
        drawLine(color, Offset(p.x - len, p.y), Offset(p.x + len, p.y), strokeWidth = 1.6f, cap = StrokeCap.Round)
        drawLine(color, Offset(p.x, p.y - len), Offset(p.x, p.y + len), strokeWidth = 1.6f, cap = StrokeCap.Round)
        drawCircle(color, radius = 1.8f, center = p)
    }
}

/** The palette turned into Compose colours once, not on every draw. */
private class VinylColors(p: VinylPalette) {
    val body = Color(p.body)
    val grooveA = Color(p.grooveA)
    val grooveB = Color(p.grooveB)
    val gap = Color(p.gap)
    val edge = Color(p.edge)
    val platter = Color(p.platter)
    val platterRim = Color(p.platterRim)
    val strobe = Color(p.strobe)
    val labelBg = Color(p.labelBg)
    val labelRing = Color(p.labelRing)
    val spindle = Color(p.spindle)
    val armTube = Color(p.armTube)
    val armHead = Color(p.armHead)
    val armWeight = Color(p.armWeight)
    val armBase = Color(p.armBase)
    val armBaseRim = Color(p.armBaseRim)
    val armPivot = Color(p.armPivot)
    val translucent = p.translucent
    val sparkle = p.sparkle
}

// angle (degrees), distance from the centre (fraction of the radius), arm length (fraction of the radius)
private val GLINTS = arrayOf(
    floatArrayOf(-48f, 0.70f, 0.07f),
    floatArrayOf(-20f, 0.52f, 0.045f),
    floatArrayOf(36f, 0.82f, 0.05f),
    floatArrayOf(118f, 0.60f, 0.06f),
    floatArrayOf(160f, 0.86f, 0.04f),
    floatArrayOf(214f, 0.74f, 0.07f),
    floatArrayOf(250f, 0.50f, 0.04f),
)

private val STROBE_RINGS = floatArrayOf(0.355f, 0.25f)
private const val STROBE_DOTS = 72

private suspend fun withFrameNanosCompat(): Long =
    androidx.compose.runtime.withFrameNanos { it }

// Geometry, as fractions of the square the turntable is drawn in.
private const val CENTER_X = 0.45f
private const val CENTER_Y = 0.52f
private const val RECORD_RADIUS = 0.40f
private const val PLATTER_RADIUS = 0.415f
private const val LABEL_FRACTION = 0.38f
private const val PIVOT_X = 0.90f
private const val PIVOT_Y = 0.10f
private const val ARM_LENGTH = 0.55f

// Tonearm angle in degrees, clockwise from "pointing straight down". These were solved so the
// needle sits on the outer groove at START and on the inner groove at END; REST parks it off the record.
private const val ARM_START_DEG = 10f
private const val ARM_END_DEG = 29f
private const val ARM_REST_DEG = -6f

private const val IDLE_DEGREES_PER_SECOND = 1f

// Inertia, in seconds.
private const val SPIN_UP_TAU = 0.35f
private const val COAST_TAU = 0.5f
private const val HAND_BRAKE_TAU = 0.07f

private const val SEEK_THROTTLE_MS = 180L
private const val VELOCITY_SAMPLES = 8
private const val MOVE_SLOP_DEGREES = 4f
private const val VELOCITY_WINDOW_MS = 25L
private const val ARM_PROGRESS_STEPS = 200f
private const val MAX_REFRESH_HZ = 144f
private const val TAP_MAX_MS = 350L
private val RAD_TO_DEG = (180.0 / PI).toFloat()

/**
 * Asks the display for its highest refresh rate (up to 144 Hz) for as long as [enabled] is true,
 * then gives the choice back to the system. Phones that run apps at 60 Hz by default will not
 * switch up on their own for a Compose animation, so without this the record can look choppy on a
 * 120 Hz screen. A rotating layer is cheap for the GPU, so the extra frames cost very little.
 */
@Composable
private fun HighRefreshRateWhile(enabled: Boolean) {
    val view = LocalView.current
    DisposableEffect(enabled, view) {
        val window = view.context.findActivity()?.window
        if (enabled && window != null) setHighRefreshRate(window, high = true)
        onDispose {
            if (enabled && window != null) setHighRefreshRate(window, high = false)
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private fun setHighRefreshRate(window: Window, high: Boolean) {
    try {
        val params = window.attributes
        if (!high) {
            if (params.preferredDisplayModeId != 0) {
                params.preferredDisplayModeId = 0
                window.attributes = params
            }
            return
        }
        val display = window.decorView.display ?: return
        val current = display.mode
        val best = display.supportedModes
            .filter { it.physicalWidth == current.physicalWidth && it.physicalHeight == current.physicalHeight }
            .filter { it.refreshRate <= MAX_REFRESH_HZ + 0.5f }
            .maxByOrNull { it.refreshRate } ?: return
        if (best.refreshRate <= current.refreshRate + 1f) return // already running that fast
        params.preferredDisplayModeId = best.modeId
        window.attributes = params
    } catch (_: Throwable) {
        // Some vendor ROMs throw on odd display setups. Smoothness is optional, never crash for it.
    }
}
