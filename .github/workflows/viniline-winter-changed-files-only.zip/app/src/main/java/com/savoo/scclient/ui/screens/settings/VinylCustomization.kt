package com.savoo.scclient.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.savoo.scclient.R
import com.savoo.scclient.data.model.RecordSpeed
import com.savoo.scclient.data.model.SnowScope
import com.savoo.scclient.data.model.SnowTint
import com.savoo.scclient.data.model.TonearmStyle
import com.savoo.scclient.data.model.VinylLabelMode
import com.savoo.scclient.data.model.VinylSettings
import com.savoo.scclient.data.model.VinylSkin
import com.savoo.scclient.ui.components.SwitchItem
import com.savoo.scclient.ui.effects.LocalVinylSettings
import com.savoo.scclient.ui.haptics.rememberHapticTick
import com.savoo.scclient.ui.screens.player.VinylTurntable
import kotlin.math.roundToInt

/**
 * The winter update's customisation: record skins and everything about the record, and the snow.
 *
 * The record preview shows the settings live while a slider is being dragged; the choice is saved
 * when the finger lets go (so dragging does not write to storage on every pixel).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun VinylCustomizationCards(
    vinyl: VinylSettings,
    onUpdate: ((VinylSettings) -> VinylSettings) -> Unit,
) {
    var draft by remember(vinyl) { mutableStateOf(vinyl) }
    val haptic = rememberHapticTick()

    fun commit(transform: (VinylSettings) -> VinylSettings) {
        val result = transform(draft).normalized()
        draft = result
        onUpdate { result }
        haptic()
    }

    fun saveDraft() {
        val result = draft.normalized()
        onUpdate { result }
    }

    SettingsSectionCard(title = stringResource(R.string.vinyl_section_title)) {
        CompositionLocalProvider(LocalVinylSettings provides draft) {
            Box(
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                contentAlignment = Alignment.Center,
            ) {
                VinylTurntable(
                    artworkUrl = null,
                    artworkSeed = "viniline",
                    isPlaying = true,
                    rate = 1f,
                    positionMs = 40_000L,
                    durationMs = 100_000L,
                    onSeek = {},
                    onScratchStart = {},
                    onScratchSpeed = {},
                    onScratchEnd = { _, _ -> },
                    modifier = Modifier.size(260.dp),
                )
            }
        }

        GroupTitle(stringResource(R.string.vinyl_skin))
        OptionChips(
            options = listOf(
                VinylSkin.BLACK to stringResource(R.string.vinyl_skin_black),
                VinylSkin.ORANGE to stringResource(R.string.vinyl_skin_orange),
                VinylSkin.ICE to stringResource(R.string.vinyl_skin_ice),
                VinylSkin.CUSTOM to stringResource(R.string.vinyl_skin_custom),
            ),
            selected = draft.skin,
            onSelect = { skin -> commit { it.copy(skin = skin) } },
        )

        if (draft.skin == VinylSkin.CUSTOM) {
            SliderRow(
                label = stringResource(R.string.settings_custom_color_hue),
                valueText = "${draft.customHue.roundToInt()}°",
                value = draft.customHue,
                range = 0f..360f,
                onChange = { draft = draft.copy(customHue = it) },
                onFinished = ::saveDraft,
            )
            SliderRow(
                label = stringResource(R.string.settings_custom_color_saturation),
                valueText = percent(draft.customSaturation),
                value = draft.customSaturation,
                range = 0f..1f,
                onChange = { draft = draft.copy(customSaturation = it) },
                onFinished = ::saveDraft,
            )
            SliderRow(
                label = stringResource(R.string.settings_custom_color_brightness),
                valueText = percent(draft.customBrightness),
                value = draft.customBrightness,
                range = 0.1f..1f,
                onChange = { draft = draft.copy(customBrightness = it) },
                onFinished = ::saveDraft,
            )
            SliderRow(
                label = stringResource(R.string.vinyl_opacity),
                valueText = percent(draft.customOpacity),
                value = draft.customOpacity,
                range = 0.25f..1f,
                onChange = { draft = draft.copy(customOpacity = it) },
                onFinished = ::saveDraft,
            )
        }

        GroupTitle(stringResource(R.string.vinyl_label))
        OptionChips(
            options = listOf(
                VinylLabelMode.ARTWORK to stringResource(R.string.vinyl_label_art),
                VinylLabelMode.COLOR to stringResource(R.string.vinyl_label_color),
            ),
            selected = draft.labelMode,
            onSelect = { mode -> commit { it.copy(labelMode = mode) } },
        )

        GroupTitle(stringResource(R.string.vinyl_tonearm))
        OptionChips(
            options = listOf(
                TonearmStyle.AUTO to stringResource(R.string.vinyl_tonearm_auto),
                TonearmStyle.SILVER to stringResource(R.string.vinyl_tonearm_silver),
                TonearmStyle.GOLD to stringResource(R.string.vinyl_tonearm_gold),
                TonearmStyle.BLACK to stringResource(R.string.vinyl_tonearm_black),
                TonearmStyle.ICE to stringResource(R.string.vinyl_tonearm_ice),
                TonearmStyle.ORANGE to stringResource(R.string.vinyl_tonearm_orange),
            ),
            selected = draft.tonearm,
            onSelect = { style -> commit { it.copy(tonearm = style) } },
        )

        GroupTitle(stringResource(R.string.vinyl_speed))
        OptionChips(
            options = listOf(
                RecordSpeed.RPM_33 to stringResource(R.string.vinyl_rpm_33),
                RecordSpeed.RPM_45 to stringResource(R.string.vinyl_rpm_45),
                RecordSpeed.RPM_78 to stringResource(R.string.vinyl_rpm_78),
            ),
            selected = draft.speed,
            onSelect = { speed -> commit { it.copy(speed = speed) } },
        )

        SliderRow(
            label = stringResource(R.string.vinyl_shine),
            valueText = percent(draft.shine),
            value = draft.shine,
            range = 0f..1f,
            onChange = { draft = draft.copy(shine = it) },
            onFinished = ::saveDraft,
        )

        FilledTonalButton(
            onClick = { commit { VinylSettings() } },
            modifier = Modifier.fillMaxWidth().padding(16.dp),
        ) {
            Text(stringResource(R.string.vinyl_reset))
        }
    }

    SettingsSectionCard(title = stringResource(R.string.winter_section_title)) {
        SwitchItem(
            title = stringResource(R.string.snow_enabled),
            subtitle = stringResource(R.string.snow_enabled_desc),
            checked = draft.snowEnabled,
            onCheckedChange = { enabled -> commit { it.copy(snowEnabled = enabled) } },
        )

        if (draft.snowEnabled) {
            SettingsDivider()
            GroupTitle(stringResource(R.string.snow_scope))
            OptionChips(
                options = listOf(
                    SnowScope.EVERYWHERE to stringResource(R.string.snow_scope_everywhere),
                    SnowScope.RECORD_ONLY to stringResource(R.string.snow_scope_record),
                ),
                selected = draft.snowScope,
                onSelect = { scope -> commit { it.copy(snowScope = scope) } },
            )

            SliderRow(
                label = stringResource(R.string.snow_density),
                valueText = percent(draft.snowDensity),
                value = draft.snowDensity,
                range = 0f..1f,
                onChange = { draft = draft.copy(snowDensity = it) },
                onFinished = ::saveDraft,
            )
            SliderRow(
                label = stringResource(R.string.snow_speed),
                valueText = "×${"%.1f".format(draft.snowSpeed)}",
                value = draft.snowSpeed,
                range = 0.3f..2f,
                onChange = { draft = draft.copy(snowSpeed = it) },
                onFinished = ::saveDraft,
            )
            SliderRow(
                label = stringResource(R.string.snow_size),
                valueText = "×${"%.1f".format(draft.snowSize)}",
                value = draft.snowSize,
                range = 0.5f..2f,
                onChange = { draft = draft.copy(snowSize = it) },
                onFinished = ::saveDraft,
            )
            SliderRow(
                label = stringResource(R.string.snow_wind),
                valueText = windText(draft.snowWind),
                value = draft.snowWind,
                range = -1f..1f,
                onChange = { draft = draft.copy(snowWind = it) },
                onFinished = ::saveDraft,
            )

            GroupTitle(stringResource(R.string.snow_tint))
            OptionChips(
                options = listOf(
                    SnowTint.WHITE to stringResource(R.string.snow_tint_white),
                    SnowTint.ICE to stringResource(R.string.snow_tint_ice),
                    SnowTint.GOLD to stringResource(R.string.snow_tint_gold),
                ),
                selected = draft.snowTint,
                onSelect = { tint -> commit { it.copy(snowTint = tint) } },
            )
            Spacer(Modifier.height(16.dp))
        }
    }
}

private fun percent(v: Float): String = "${(v * 100).roundToInt()}%"

private fun windText(v: Float): String = when {
    v < -0.05f -> "← ${(-v * 100).roundToInt()}%"
    v > 0.05f -> "${(v * 100).roundToInt()}% →"
    else -> "0%"
}

@Composable
private fun GroupTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp),
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun <T> OptionChips(
    options: List<Pair<T, String>>,
    selected: T,
    onSelect: (T) -> Unit,
) {
    FlowRow(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { (value, label) ->
            FilterChip(
                selected = value == selected,
                onClick = { onSelect(value) },
                label = { Text(label) },
            )
        }
    }
}

@Composable
private fun SliderRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    onFinished: () -> Unit,
) {
    LabeledControl(label, valueText) {
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            onValueChangeFinished = onFinished,
            valueRange = range,
        )
    }
}

/** A label and its value on one line, the control underneath. */
@Composable
private fun LabeledControl(label: String, valueText: String, control: @Composable () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(
                valueText,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.width(72.dp),
            )
        }
        control()
    }
}
