package com.savoo.scclient.ui.effects

import androidx.compose.runtime.compositionLocalOf
import com.savoo.scclient.data.model.VinylSettings

/** The current vinyl and snow settings, provided once at the root so any screen can read them. */
val LocalVinylSettings = compositionLocalOf { VinylSettings() }
