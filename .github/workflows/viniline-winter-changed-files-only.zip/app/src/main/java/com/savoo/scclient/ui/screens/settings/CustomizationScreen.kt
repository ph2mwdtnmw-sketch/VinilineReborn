package com.savoo.scclient.ui.screens.settings

import com.savoo.scclient.ui.components.ChipLabel
import com.savoo.scclient.ui.navigation.dockInset
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.ButtonGroup
import androidx.compose.material3.ButtonGroupDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialShapes
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.ToggleButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.toShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.savoo.scclient.R
import com.savoo.scclient.data.repository.AppBackgroundMode
import com.savoo.scclient.data.repository.ArtworkGlowSource
import com.savoo.scclient.data.repository.ArtworkShape
import com.savoo.scclient.data.repository.AppIconOption
import com.savoo.scclient.data.repository.DarkModeOption
import com.savoo.scclient.data.repository.DividerStyle
import com.savoo.scclient.data.repository.HomeSection
import com.savoo.scclient.data.repository.HomeSectionConfig
import com.savoo.scclient.data.repository.MaxArtworkScalePercent
import com.savoo.scclient.data.repository.MinArtworkScalePercent
import com.savoo.scclient.data.repository.MaxFontRoundness
import com.savoo.scclient.data.repository.MinFontRoundness
import com.savoo.scclient.data.repository.PlayerBackgroundStyle
import com.savoo.scclient.data.repository.PlayerStyle
import com.savoo.scclient.data.repository.SeekBarStyle
import com.savoo.scclient.ui.components.MorphingArtworkShape
import com.savoo.scclient.ui.components.SwitchItem
import com.savoo.scclient.ui.components.artworkProgressRing
import com.savoo.scclient.ui.components.polygon
import com.savoo.scclient.ui.components.rememberArtworkShape
import com.savoo.scclient.ui.haptics.rememberHapticTick
import kotlin.math.roundToInt
import com.savoo.scclient.ui.theme.AppColorTheme

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun ColorThemeSwatch(
    theme: AppColorTheme,
    selected: Boolean,
    onClick: () -> Unit,
    swatchColor: Color = theme.seedPrimary,
) {
    val shape = if (selected) MaterialShapes.Cookie9Sided.toShape() else CircleShape
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(64.dp),
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(shape)
                .background(swatchColor)
                .clickable { onClick() },
            contentAlignment = Alignment.Center,
        ) {
            if (selected) {
                Icon(
                    Icons.Filled.Check,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(22.dp),
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            theme.displayName,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}

@Composable
private fun CustomColorPicker(color: Color, onColorChange: (Color) -> Unit) {
    val hsv = remember(color) {
        FloatArray(3).also { android.graphics.Color.colorToHSV(color.toArgb(), it) }
    }
    var hue by remember(color) { mutableFloatStateOf(hsv[0]) }
    var saturation by remember(color) { mutableFloatStateOf(hsv[1]) }
    var value by remember(color) { mutableFloatStateOf(hsv[2]) }
    val liveColor = Color.hsv(hue, saturation, value)

    fun commit() = onColorChange(Color.hsv(hue, saturation, value))

    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(liveColor),
            )
            Spacer(Modifier.width(12.dp))
            Text(
                stringResource(R.string.settings_custom_color),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            stringResource(R.string.settings_custom_color_hue),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Slider(
            value = hue,
            onValueChange = { hue = it },
            onValueChangeFinished = { commit() },
            valueRange = 0f..360f,
        )
        Text(
            stringResource(R.string.settings_custom_color_saturation),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Slider(
            value = saturation,
            onValueChange = { saturation = it },
            onValueChangeFinished = { commit() },
            valueRange = 0f..1f,
        )
        Text(
            stringResource(R.string.settings_custom_color_brightness),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Slider(
            value = value,
            onValueChange = { value = it },
            onValueChangeFinished = { commit() },
            valueRange = 0.1f..1f,
        )
    }
}

private fun ArtworkShape.labelRes(): Int = when (this) {
    ArtworkShape.BLOB -> R.string.artwork_shape_blob
    ArtworkShape.CIRCLE -> R.string.artwork_shape_circle
    ArtworkShape.SQUARE -> R.string.artwork_shape_square
    ArtworkShape.COOKIE_9 -> R.string.artwork_shape_cookie_9
    ArtworkShape.COOKIE_12 -> R.string.artwork_shape_cookie_12
    ArtworkShape.CLOVER_4 -> R.string.artwork_shape_clover_4
    ArtworkShape.CLOVER_8 -> R.string.artwork_shape_clover_8
    ArtworkShape.SUNNY -> R.string.artwork_shape_sunny
    ArtworkShape.SOFT_BURST -> R.string.artwork_shape_soft_burst
    ArtworkShape.FLOWER -> R.string.artwork_shape_flower
    ArtworkShape.PUFFY_DIAMOND -> R.string.artwork_shape_puffy_diamond
    ArtworkShape.HEART -> R.string.artwork_shape_heart
}

@Composable
private fun ArtworkShapePreview(shape: ArtworkShape, ringEnabled: Boolean) {
    val clip = rememberArtworkShape(shape)
    val scheme = MaterialTheme.colorScheme
    Box(
        modifier = Modifier.fillMaxWidth().padding(top = 28.dp, bottom = 20.dp),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(136.dp)
                .clip(clip)
                .background(Brush.linearGradient(listOf(scheme.primary, scheme.tertiary))),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Filled.MusicNote,
                contentDescription = null,
                tint = scheme.onPrimary,
                modifier = Modifier.size(44.dp),
            )
        }
        if (ringEnabled) {
            Box(
                modifier = Modifier
                    .requiredSize(136.dp + 24.dp)
                    .artworkProgressRing(clip, { 0.62f }, scheme.primary, 3.dp),
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ArtworkShapePicker(selected: ArtworkShape, onSelect: (ArtworkShape) -> Unit) {
    val haptic = rememberHapticTick()
    val scheme = MaterialTheme.colorScheme
    FlowRow(
        modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        ArtworkShape.entries.forEach { shape ->
            val isSelected = shape == selected
            val clip = remember(shape) {
                val polygon = shape.polygon().normalized()
                MorphingArtworkShape(androidx.graphics.shapes.Morph(polygon, polygon), 1f)
            }
            val description = stringResource(shape.labelRes())
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(clip)
                    .background(if (isSelected) scheme.primary else scheme.surfaceContainerHighest)
                    .clickable(onClickLabel = description) { haptic(); onSelect(shape) }
                    .semantics { contentDescription = description; this.selected = isSelected },
                contentAlignment = Alignment.Center,
            ) {
                if (isSelected) {
                    Icon(Icons.Filled.Check, contentDescription = null, tint = scheme.onPrimary, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

private fun labelResFor(section: HomeSection): Int = when (section) {
    HomeSection.JUMP_BACK_IN -> R.string.home_section_jump_back_in
    HomeSection.FAVORITES -> R.string.home_section_favorites
    HomeSection.OFFLINE -> R.string.home_section_offline
    HomeSection.ARTISTS -> R.string.home_section_artists
    HomeSection.PLAYLISTS -> R.string.home_section_playlists
}

@Composable
private fun HomeSectionRow(
    config: HomeSectionConfig,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    onToggleVisible: (Boolean) -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(checked = config.visible, onCheckedChange = onToggleVisible)
        Text(
            stringResource(labelResFor(config.section)),
            style = MaterialTheme.typography.bodyLarge,
            color = if (config.visible) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f),
        )
        IconButton(onClick = onMoveUp, enabled = canMoveUp) {
            Icon(Icons.Filled.KeyboardArrowUp, contentDescription = null)
        }
        IconButton(onClick = onMoveDown, enabled = canMoveDown) {
            Icon(Icons.Filled.KeyboardArrowDown, contentDescription = null)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class, ExperimentalLayoutApi::class)
@Composable
fun CustomizationScreen(
    viewModel: SettingsViewModel = hiltViewModel(),
    onBack: () -> Unit = {},
) {
    val settings by viewModel.settings.collectAsState()
    val haptic = rememberHapticTick()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings_customization), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                }
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(bottom = dockInset()),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            Spacer(Modifier.height(0.dp))

            // Winter update: record skins, record customisation and the snow.
            VinylCustomizationCards(
                vinyl = settings.vinyl,
                onUpdate = { transform -> viewModel.updateVinyl(transform) },
            )

            SettingsSectionCard(title = stringResource(R.string.settings_color_theme)) {
                FlowRow(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    AppColorTheme.entries.filter { it != AppColorTheme.DYNAMIC_TRACK }.forEach { theme ->
                        ColorThemeSwatch(
                            theme = theme,
                            selected = settings.colorTheme == theme,
                            onClick = { viewModel.setColorTheme(theme) },
                            swatchColor = if (theme == AppColorTheme.CUSTOM) settings.customSeedColor else theme.seedPrimary,
                        )
                    }
                }
                if (settings.colorTheme == AppColorTheme.CUSTOM) {
                    SettingsDivider()
                    CustomColorPicker(
                        color = settings.customSeedColor,
                        onColorChange = { viewModel.setCustomSeedColor(it) },
                    )
                }
                SettingsDivider()
                SwitchItem(
                    title = stringResource(R.string.settings_dynamic_color),
                    subtitle = stringResource(R.string.settings_dynamic_color_desc),
                    checked = settings.dynamicFromTrack,
                    onCheckedChange = { viewModel.setDynamicFromTrack(it) }
                )
            }

            SettingsSectionCard(title = stringResource(R.string.settings_app_icon)) {
                val iconOptions = AppIconOption.entries
                val iconLabelResIds = listOf(R.string.settings_app_icon_normal, R.string.settings_app_icon_dynamic)
                ButtonGroup(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    iconOptions.forEachIndexed { index, option ->
                        val shapes = when (index) {
                            0 -> ButtonGroupDefaults.connectedLeadingButtonShapes()
                            iconOptions.lastIndex -> ButtonGroupDefaults.connectedTrailingButtonShapes()
                            else -> ButtonGroupDefaults.connectedMiddleButtonShapes()
                        }
                        ToggleButton(
                            checked = settings.appIcon == option,
                            onCheckedChange = { checked -> if (checked) { haptic(); viewModel.setAppIcon(option) } },
                            modifier = Modifier.weight(1f),
                            shapes = shapes,
                        ) {
                            ChipLabel(stringResource(iconLabelResIds[index]), style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
                Text(
                    stringResource(R.string.settings_app_icon_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
                )
            }

            SettingsSectionCard(title = stringResource(R.string.settings_dark_theme)) {
                val modes = DarkModeOption.entries
                val labelResIds = listOf(R.string.settings_dark_system, R.string.settings_dark_light, R.string.settings_dark_dark)
                ButtonGroup(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    modes.forEachIndexed { index, mode ->
                        val shapes = when (index) {
                            0 -> ButtonGroupDefaults.connectedLeadingButtonShapes()
                            modes.lastIndex -> ButtonGroupDefaults.connectedTrailingButtonShapes()
                            else -> ButtonGroupDefaults.connectedMiddleButtonShapes()
                        }
                        ToggleButton(
                            checked = settings.darkMode == mode,
                            onCheckedChange = { checked -> if (checked) { haptic(); viewModel.setDarkMode(mode) } },
                            modifier = Modifier.weight(1f),
                            shapes = shapes,
                        ) {
                            ChipLabel(stringResource(labelResIds[index]), style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }

            SettingsSectionCard(title = stringResource(R.string.settings_home_sections)) {
                Text(
                    stringResource(R.string.settings_home_sections_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 4.dp),
                )
                Column(modifier = Modifier.padding(bottom = 8.dp)) {
                    settings.homeSections.forEachIndexed { index, config ->
                        HomeSectionRow(
                            config = config,
                            canMoveUp = index > 0,
                            canMoveDown = index < settings.homeSections.lastIndex,
                            onToggleVisible = { visible ->
                                haptic()
                                val updated = settings.homeSections.toMutableList()
                                updated[index] = config.copy(visible = visible)
                                viewModel.setHomeSections(updated)
                            },
                            onMoveUp = {
                                haptic()
                                val updated = settings.homeSections.toMutableList()
                                updated[index] = updated[index - 1].also { updated[index - 1] = updated[index] }
                                viewModel.setHomeSections(updated)
                            },
                            onMoveDown = {
                                haptic()
                                val updated = settings.homeSections.toMutableList()
                                updated[index] = updated[index + 1].also { updated[index + 1] = updated[index] }
                                viewModel.setHomeSections(updated)
                            },
                        )
                    }
                }
            }

            SettingsSectionCard(title = stringResource(R.string.settings_app_background)) {
                run {
                    val modes = AppBackgroundMode.entries
                    val modeLabelResIds = listOf(
                        R.string.settings_app_background_dynamic,
                        R.string.settings_app_background_default,
                        R.string.settings_app_background_custom,
                        R.string.settings_app_background_player_only,
                    )
                    val modeDescResIds = listOf(
                        R.string.settings_app_background_dynamic_desc,
                        R.string.settings_app_background_default_desc,
                        R.string.settings_app_background_custom_desc,
                        R.string.settings_app_background_player_only_desc,
                    )
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        modes.chunked(2).forEach { row ->
                            ButtonGroup(modifier = Modifier.fillMaxWidth()) {
                                row.forEachIndexed { indexInRow, mode ->
                                    val index = modes.indexOf(mode)
                                    val shapes = if (indexInRow == 0) {
                                        ButtonGroupDefaults.connectedLeadingButtonShapes()
                                    } else {
                                        ButtonGroupDefaults.connectedTrailingButtonShapes()
                                    }
                                    ToggleButton(
                                        checked = settings.backgroundMode == mode,
                                        onCheckedChange = { checked -> if (checked) { haptic(); viewModel.setBackgroundMode(mode) } },
                                        modifier = Modifier.weight(1f),
                                        shapes = shapes,
                                    ) {
                                        ChipLabel(
                                            stringResource(modeLabelResIds[index]),
                                            style = MaterialTheme.typography.labelLarge,
                                        )
                                    }
                                }
                            }
                        }
                    }
                    Text(
                        stringResource(modeDescResIds[modes.indexOf(settings.backgroundMode).coerceAtLeast(0)]),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp).padding(bottom = 12.dp),
                    )
                    if (settings.backgroundMode == AppBackgroundMode.CUSTOM) {
                        CustomColorPicker(
                            color = settings.backgroundCustomColor,
                            onColorChange = { viewModel.setBackgroundCustomColor(it) },
                        )
                    }
                    SettingsDivider()
                    Text(
                        stringResource(R.string.settings_dividers),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp),
                    )
                    Text(
                        stringResource(R.string.settings_dividers_desc),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 2.dp),
                    )
                    val dividerStyles = DividerStyle.entries
                    val dividerLabelResIds = listOf(
                        R.string.settings_dividers_hidden,
                        R.string.settings_dividers_subtle,
                        R.string.settings_dividers_bright,
                    )
                    ButtonGroup(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        dividerStyles.forEachIndexed { index, style ->
                            val shapes = when (index) {
                                0 -> ButtonGroupDefaults.connectedLeadingButtonShapes()
                                dividerStyles.lastIndex -> ButtonGroupDefaults.connectedTrailingButtonShapes()
                                else -> ButtonGroupDefaults.connectedMiddleButtonShapes()
                            }
                            ToggleButton(
                                checked = settings.dividerStyle == style,
                                onCheckedChange = { checked -> if (checked) { haptic(); viewModel.setDividerStyle(style) } },
                                modifier = Modifier.weight(1f),
                                shapes = shapes,
                            ) {
                                ChipLabel(
                                    stringResource(dividerLabelResIds[index]),
                                    style = MaterialTheme.typography.labelLarge,
                                )
                            }
                        }
                    }
                }
            }

            SettingsSectionCard(title = stringResource(R.string.settings_artwork_glow)) {
                run {
                    val sources = listOf(ArtworkGlowSource.ARTWORK, ArtworkGlowSource.THEME, ArtworkGlowSource.OFF)
                    val labels = listOf(
                        R.string.settings_artwork_glow_artwork,
                        R.string.settings_artwork_glow_theme,
                        R.string.settings_artwork_glow_off,
                    )
                    ButtonGroup(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        sources.forEachIndexed { index, source ->
                            val shapes = when (index) {
                                0 -> ButtonGroupDefaults.connectedLeadingButtonShapes()
                                sources.lastIndex -> ButtonGroupDefaults.connectedTrailingButtonShapes()
                                else -> ButtonGroupDefaults.connectedMiddleButtonShapes()
                            }
                            ToggleButton(
                                checked = settings.artworkGlowSource == source,
                                onCheckedChange = { checked -> if (checked) { haptic(); viewModel.setArtworkGlowSource(source) } },
                                modifier = Modifier.weight(1f),
                                shapes = shapes,
                            ) {
                                ChipLabel(stringResource(labels[index]), style = MaterialTheme.typography.labelLarge)
                            }
                        }
                    }
                    SwitchItem(
                        title = stringResource(R.string.settings_marquee_titles),
                        subtitle = stringResource(R.string.settings_marquee_titles_desc),
                        checked = settings.marqueeTitles,
                        onCheckedChange = { viewModel.setMarqueeTitles(it) },
                    )
                }
            }

            SettingsSectionCard(title = stringResource(R.string.settings_liquid_glass)) {
                SwitchItem(
                    title = stringResource(R.string.settings_liquid_glass),
                    subtitle = stringResource(R.string.settings_liquid_glass_desc),
                    checked = settings.liquidGlass,
                    onCheckedChange = { viewModel.setLiquidGlass(it) }
                )
                SwitchItem(
                    title = stringResource(R.string.settings_dock_background),
                    subtitle = stringResource(R.string.settings_dock_background_desc),
                    checked = settings.dockBackground,
                    onCheckedChange = { viewModel.setDockBackground(it) }
                )
            }

            SettingsSectionCard(title = stringResource(R.string.settings_player_style)) {
                run {
                    val styles = listOf(PlayerStyle.PIXEL, PlayerStyle.CLASSIC)
                    val styleLabelResIds = listOf(R.string.settings_player_style_pixel, R.string.settings_player_style_legacy)
                    ButtonGroup(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        styles.forEachIndexed { index, style ->
                            val shapes = when (index) {
                                0 -> ButtonGroupDefaults.connectedLeadingButtonShapes()
                                styles.lastIndex -> ButtonGroupDefaults.connectedTrailingButtonShapes()
                                else -> ButtonGroupDefaults.connectedMiddleButtonShapes()
                            }
                            ToggleButton(
                                checked = settings.playerStyle == style,
                                onCheckedChange = { checked -> if (checked) { haptic(); viewModel.setPlayerStyle(style) } },
                                modifier = Modifier.weight(1f),
                                shapes = shapes,
                            ) {
                                ChipLabel(stringResource(styleLabelResIds[index]), style = MaterialTheme.typography.labelLarge)
                            }
                        }
                    }
                    if (settings.playerStyle == PlayerStyle.PIXEL) {
                        SwitchItem(
                            title = stringResource(R.string.settings_pixel_glow),
                            subtitle = stringResource(R.string.settings_pixel_glow_desc),
                            checked = settings.pixelGlowEnabled,
                            onCheckedChange = { viewModel.setPixelGlowEnabled(it) },
                        )
                    }
                }
            }

            SettingsSectionCard(title = stringResource(R.string.settings_font)) {
                SwitchItem(
                    title = stringResource(R.string.settings_font_roundness),
                    subtitle = stringResource(R.string.settings_font_roundness_desc),
                    checked = settings.fontRoundnessEnabled,
                    onCheckedChange = { viewModel.setFontRoundnessEnabled(it) },
                )
                if (settings.fontRoundnessEnabled) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            stringResource(R.string.settings_font_roundness_level),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f),
                        )
                        Text(
                            stringResource(R.string.settings_font_roundness_format, settings.fontRoundness),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                    Slider(
                        value = settings.fontRoundness.toFloat(),
                        onValueChange = { viewModel.setFontRoundness(it.roundToInt()) },
                        onValueChangeFinished = { haptic() },
                        valueRange = MinFontRoundness.toFloat()..MaxFontRoundness.toFloat(),
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    )
                    Text(
                        stringResource(R.string.settings_font_sample),
                        style = MaterialTheme.typography.headlineSmall,
                        modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp),
                    )
                }
            }

            SettingsSectionCard(title = stringResource(R.string.settings_artwork_shape)) {
                ArtworkShapePreview(settings.artworkShape, settings.artworkRingEnabled)
                ArtworkShapePicker(selected = settings.artworkShape, onSelect = { viewModel.setArtworkShape(it) })
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        stringResource(R.string.settings_artwork_size),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        stringResource(R.string.settings_artwork_size_format, settings.artworkScalePercent),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                Slider(
                    value = settings.artworkScalePercent.toFloat(),
                    onValueChange = { viewModel.setArtworkScalePercent(it.roundToInt()) },
                    onValueChangeFinished = { haptic() },
                    valueRange = MinArtworkScalePercent.toFloat()..MaxArtworkScalePercent.toFloat(),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                )
                SwitchItem(
                    title = stringResource(R.string.settings_artwork_ring),
                    subtitle = stringResource(R.string.settings_artwork_ring_desc),
                    checked = settings.artworkRingEnabled,
                    onCheckedChange = { viewModel.setArtworkRingEnabled(it) },
                )
                SwitchItem(
                    title = stringResource(R.string.settings_beat_pulse),
                    subtitle = stringResource(R.string.settings_beat_pulse_desc),
                    checked = settings.beatPulseEnabled,
                    onCheckedChange = { viewModel.setBeatPulseEnabled(it) },
                )
                SwitchItem(
                    title = stringResource(R.string.settings_animated_artwork),
                    subtitle = stringResource(R.string.settings_animated_artwork_desc),
                    checked = settings.animatedArtwork,
                    onCheckedChange = { viewModel.setAnimatedArtwork(it) },
                )
            }

            if (settings.playerStyle == PlayerStyle.CLASSIC) {
                SettingsSectionCard(title = stringResource(R.string.settings_player_background)) {
                    run {
                        val styles = listOf(PlayerBackgroundStyle.ORB, PlayerBackgroundStyle.MINIMAL)
                        val styleLabelResIds = listOf(
                            R.string.settings_player_background_orb,
                            R.string.settings_player_background_minimal,
                        )
                        ButtonGroup(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                            styles.forEachIndexed { index, style ->
                                val shapes = when (index) {
                                    0 -> ButtonGroupDefaults.connectedLeadingButtonShapes()
                                    styles.lastIndex -> ButtonGroupDefaults.connectedTrailingButtonShapes()
                                    else -> ButtonGroupDefaults.connectedMiddleButtonShapes()
                                }
                                ToggleButton(
                                    checked = settings.playerBackgroundStyle == style,
                                    onCheckedChange = { checked -> if (checked) { haptic(); viewModel.setPlayerBackgroundStyle(style) } },
                                    modifier = Modifier.weight(1f),
                                    shapes = shapes,
                                ) {
                                    ChipLabel(stringResource(styleLabelResIds[index]), style = MaterialTheme.typography.labelLarge)
                                }
                            }
                        }
                    }
                }
            }

            SettingsSectionCard(title = stringResource(R.string.settings_seek_bar_style)) {
                run {
                    val styles = SeekBarStyle.entries
                    val styleLabelResIds = listOf(R.string.settings_seek_bar_style_classic, R.string.settings_seek_bar_style_wavy, R.string.settings_seek_bar_style_waveform)
                    ButtonGroup(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                        styles.forEachIndexed { index, style ->
                            val shapes = when (index) {
                                0 -> ButtonGroupDefaults.connectedLeadingButtonShapes()
                                styles.lastIndex -> ButtonGroupDefaults.connectedTrailingButtonShapes()
                                else -> ButtonGroupDefaults.connectedMiddleButtonShapes()
                            }
                            ToggleButton(
                                checked = settings.seekBarStyle == style,
                                onCheckedChange = { checked -> if (checked) { haptic(); viewModel.setSeekBarStyle(style) } },
                                modifier = Modifier.weight(1f),
                                shapes = shapes,
                            ) {
                                ChipLabel(stringResource(styleLabelResIds[index]), style = MaterialTheme.typography.labelLarge)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
        }
    }
}
