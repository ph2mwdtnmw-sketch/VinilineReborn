package com.savoo.scclient.ui.effects

import android.app.ActivityManager
import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import com.savoo.scclient.data.model.SnowTint
import com.savoo.scclient.data.model.VinylSettings
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Falling snow, drawn over whatever is below it. It only draws: it never takes touches.
 *
 * Cheap on purpose: one frame loop, flakes kept in plain arrays, the animation state is read only
 * while drawing (so nothing recomposes per frame), and nothing runs at all when snow is off.
 * Phones that report themselves as low-RAM get fewer flakes and half the frame rate.
 */
@Composable
fun SnowOverlay(
    settings: VinylSettings,
    modifier: Modifier = Modifier.fillMaxSize(),
) {
    if (!settings.snowEnabled || settings.snowDensity <= 0f) return

    val context = LocalContext.current
    val lowRam = remember {
        (context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager)?.isLowRamDevice == true
    }
    val capacity = if (lowRam) CAPACITY_LOW_RAM else CAPACITY
    val field = remember(capacity) { SnowField(capacity) }
    val latest by rememberUpdatedState(settings)
    var frame by remember { mutableLongStateOf(0L) }

    LaunchedEffect(field) {
        var last = withFrameNanos { it }
        while (true) {
            if (lowRam) withFrameNanos { it } // every other frame
            val now = withFrameNanos { it }
            val dt = (now - last) / 1_000_000_000f
            last = now
            val s = latest
            field.update(dt, (s.snowDensity * capacity).roundToInt(), s.snowSpeed, s.snowWind)
            frame = now
        }
    }

    Canvas(modifier = modifier) {
        @Suppress("UNUSED_VARIABLE")
        val redrawOnEveryFrame = frame // reading it here (not in composition) is what triggers the redraw
        val s = latest
        val count = (s.snowDensity * capacity).roundToInt()
        val base = tintColor(s.snowTint)
        val unit = min(size.width, size.height) * 0.0075f * s.snowSize
        for (i in 0 until count) {
            val sc = field.scale[i]
            val r = unit * sc * 1.2f
            val center = Offset(field.drawX(i) * size.width, field.y[i] * size.height)
            val color = base.copy(alpha = 0.35f + 0.6f * sc)
            if (sc > 0.82f) drawSnowflake(center, r * 1.7f, color) else drawCircle(color, r, center)
        }
    }
}

private fun tintColor(tint: SnowTint): Color = when (tint) {
    SnowTint.WHITE -> Color(0xFFFFFFFF)
    SnowTint.ICE -> Color(0xFFBFE3FF)
    SnowTint.GOLD -> Color(0xFFFFE9A8)
}

/** Six arms made of three crossing lines. */
private fun DrawScope.drawSnowflake(center: Offset, radius: Float, color: Color) {
    val stroke = (radius * 0.2f).coerceAtLeast(1f)
    for (angle in SNOWFLAKE_ANGLES) {
        rotate(degrees = angle, pivot = center) {
            drawLine(
                color = color,
                start = Offset(center.x - radius, center.y),
                end = Offset(center.x + radius, center.y),
                strokeWidth = stroke,
                cap = StrokeCap.Round,
            )
        }
    }
}

private val SNOWFLAKE_ANGLES = floatArrayOf(0f, 60f, 120f)
private const val CAPACITY = 160
private const val CAPACITY_LOW_RAM = 60
